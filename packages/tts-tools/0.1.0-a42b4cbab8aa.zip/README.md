# TTS Tools · 语音文件生成

为 Aide 的 AI 对话提供 `tts_voices`、`tts_generate` 工具。默认 TTS 保持用于助理朗读；本插件专门生成可下载的 MP3/WAV 音频文件，不改变默认提供商、音色或朗读配置。

需要 Aide 0.1.17.5 RC4 或具有 TTS Tools 桥接的宿主。选择已配置的非实时 Qwen-Audio-TTS 3.0/3.1 flash/plus 模型，使用模型提供商保险库中的 API Key。插件不接触密钥、不自行联网。未指定模型时需要启用支持 speech 输出评分的 AutoAiModelRouter 0.1.2；显式指定模型时不需要路由插件。账户开通、地域与配额仍以实际调用为准。

示例：`请使用 tts_generate 把“你好，测试成功。”生成 MP3。` 文案最长 600 字；可指定模型、官方系统音色 ID、mp3/wav。文件保存在 `generated/speech/`。同一任务只生成一份音频；提交状态不明确时不自动重新收费生成。当前不支持声音复刻、实时麦克风或批量音频。read-only 沙箱不执行生成写入。旧宿主明确报版本不支持，不伪造音频或把文字文件改名为 MP3。

官方协议：https://help.aliyun.com/zh/model-studio/qwen-audio-tts-http-api

MIT License，见 LICENSE。
