'use strict';
const unsupported=()=>{throw Error('需要支持 TTS Tools 原生桥接的 Aide 0.1.17.5 RC4 或更新宿主。');};
module.exports={name:'tts-tools',apply(ctx){
 ctx.tool({name:'tts_voices',description:'查询语音文件生成支持的系统音色和格式；独立于助理默认朗读设置。',parameters:{type:'object',properties:{},additionalProperties:false},scheduling:{resources:[]},handler:unsupported});
 ctx.tool({name:'tts_generate',description:'把用户明确给出的文案生成可下载的 MP3/WAV 文件。不要把任务指令当作文案。未指定模型时由已启用的 Auto 路由按语音生成能力评分选择；不修改助理默认朗读。不自动重试已提交的生成任务，同一任务仅生成一份文件。',parameters:{type:'object',properties:{text:{type:'string',minLength:1,maxLength:600,description:'需要朗读的准确文案'},model:{type:'string',description:'可选，已配置的非实时 Qwen-Audio-TTS 模型 ID'},voice:{type:'string',description:'可选，模型支持的官方音色 ID，默认系统音色'},format:{type:'string',enum:['mp3','wav'],default:'mp3'}},required:['text'],additionalProperties:false},scheduling:{resources:[{root:'workspace',path:'generated/speech',access:'write'}]},handler:unsupported});
}};
