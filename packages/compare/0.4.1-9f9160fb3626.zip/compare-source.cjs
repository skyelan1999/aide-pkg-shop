'use strict';
const fs=require('node:fs');
const path=require('node:path');
module.exports=async function prepare(operation,args,api,settings={}){
 if(!api?.sources)throw Error('Compare 商业版需要支持本地来源校验的 Aide');
 if(!args||typeof args!=='object'||Array.isArray(args)||Object.hasOwn(args,'sources'))throw Error('比较参数无效');
 for(const key of ['fileSource','leftSource','rightSource']){
  if(Object.hasOwn(args,key)&&args[key]!=='workspace')throw Error('Compare 商业版暂只支持同机工作区，不支持引用来源和 SSH/SFTP');
 }
 const root=await api.sources({operation:'localRoot',source:'workspace'});
 if(typeof root.workspace!=='string'||!path.isAbsolute(root.workspace)||typeof api.workspaceRoot!=='string'||!path.isAbsolute(api.workspaceRoot))throw Error('本机 Aide 工作区不可用');
 const workspace=fs.realpathSync(root.workspace);
 if(fs.realpathSync(api.workspaceRoot)!==workspace)throw Error('Aide 工作区已变化');
 const clean={...args};
 for(const selector of ['fileSource','leftSource','rightSource'])delete clean[selector];
 const useDocker=settings.offlineMacDockerWorkspace===true&&settings.offlineAutoConnect!==false&&settings.offlineConnectionMode!=='manual'
  &&process.platform==='linux'&&fs.existsSync('/.dockerenv')&&fs.existsSync('/run/pp-license/connection.json');
 const prefix='/local/Users/';
 let workerRoot=workspace;
 if(useDocker&&workspace.startsWith(prefix)&&workspace===path.normalize(root.workspace)&&workspace.slice(prefix.length).split('/').length>=2){
  // The standard Mac Docker Desktop bind is /Users -> /local/Users. The host
  // service still requires an exact match with its independently pinned root.
  workerRoot=workspace.slice('/local'.length);
 }
 return {workspace:workerRoot,args:clean,extra:operation==='status'?{sources:[{id:'workspace',name:'工作区',type:'local'}]}:{}};
};
