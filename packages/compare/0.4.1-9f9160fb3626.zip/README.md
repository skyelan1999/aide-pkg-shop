# Compare · 专有商业版

通过 Aide 市场安装薄插件。需在本机安装匹配的共享离线授权组件、配置同机工作区，再导出设备申请并导入 .plicense。

获取报价、售后、问题反馈：business@sklastu.com

## 0.4.1：共享离线组件与同机 Docker Desktop

有效授权及 0.4.0 共享离线组件无需更换。默认仍只接受原生本机工作区。Mac 上如使用 AIDE 的标准 Docker Desktop 本地挂载，请按安装说明设置同一个宿主工作区和只读 bridge，再在 Compare 设置启用「映射 Mac Docker Desktop 工作区」，保持自动连接并重开工作台。此开关不支持远程或自定义挂载。导出设备申请后等 AIDE 显示「保存文件」；申请名以 Compare- 开头。
