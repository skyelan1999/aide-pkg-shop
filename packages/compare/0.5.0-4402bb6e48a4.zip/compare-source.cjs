'use strict';
const fs=require('node:fs');
const path=require('node:path');
const workspaceLabel={id:'workspace',name:'工作区',type:'local'};
const localGitType=(type)=>type==='local';
const gitOps=new Set(['git','git_refs','git_file','browse']);
module.exports=async function prepare(operation,args,api,settings={}){
 if(!api?.sources)throw Error('Compare 商业版需要支持本地来源校验的 Aide');
 if(!args||typeof args!=='object'||Array.isArray(args)||Object.hasOwn(args,'sources'))throw Error('比较参数无效');
 if(['leftSource','rightSource'].some(key=>Object.hasOwn(args,key)&&args[key]!=='workspace'))throw Error('商业版的跨来源文件对比未开放；Git 日志可选择已授权的本地引用');
 const source=Object.hasOwn(args,'fileSource')?args.fileSource:'workspace';
 const reference=source!=='workspace';
 if(reference&&(!gitOps.has(operation)||typeof source!=='string'||!source.startsWith('source:')))throw Error('请选择当前工作区或 Aide 已添加的本地 Git 引用');
 function checkedRoot(root){
  if(typeof root?.workspace!=='string'||!path.isAbsolute(root.workspace))throw Error('本机 Aide 来源不可用');
  const canonical=fs.realpathSync(root.workspace);
  const useDocker=settings.offlineMacDockerWorkspace===true&&settings.offlineAutoConnect!==false&&settings.offlineConnectionMode!=='manual'
   &&process.platform==='linux'&&fs.existsSync('/.dockerenv')&&fs.existsSync('/run/pp-license/connection.json');
  if(useDocker&&canonical.startsWith('/local/Users/')&&canonical===path.normalize(root.workspace)&&canonical.slice('/local/Users/'.length).split('/').length>=2)
   return {canonical,worker:canonical.slice('/local'.length)};
  return {canonical,worker:canonical};
 }
 const current=checkedRoot(await api.sources({operation:'localRoot',source:'workspace'}));
 if(typeof api.workspaceRoot!=='string'||!path.isAbsolute(api.workspaceRoot)||fs.realpathSync(api.workspaceRoot)!==current.canonical)throw Error('Aide 工作区已变化');
 let selected=current,extra={};
 if(reference){
  const root=await api.sources({operation:'localRoot',source});
  if(root.source?.id!==source||!localGitType(root.source.type))throw Error('Git 日志仅支持本地引用，不支持 SSH/SFTP');
  selected=checkedRoot(root);
 }
 if(operation==='status'){
  const listing=await api.sources({operation:'sources'});
  const refs=(Array.isArray(listing?.sources)?listing.sources:[]).filter(x=>typeof x?.id==='string'&&x.id.startsWith('source:')&&localGitType(x.type));
  extra={sources:[workspaceLabel],gitSources:[workspaceLabel,...refs.map(({id,name,type})=>({id,name,type}))]};
 }
 const clean={...args};
 for(const selector of ['fileSource','leftSource','rightSource'])delete clean[selector];
 return {workspace:selected.worker,args:clean,extra};
};
