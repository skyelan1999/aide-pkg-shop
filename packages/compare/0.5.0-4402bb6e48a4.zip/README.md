# Compare 0.5.0 商业版

独立的 Git 日志页：左侧分支树，中间提交图，右侧提交说明、父提交与改动文件。可切换 AIDE 工作区和已添加的本地 Git 引用。两页共享来源与仓库；选中分支或提交后，点「带到 Git 比较」即可预填 HEAD 与目标版本。

Gerrit Change、GitHub PR、GitLab MR 按已缓存的 Git 引用归类。不会 fetch、联网读平台检查或修改仓库。CI/审批状态显示未连接；暂存、未暂存、未跟踪、冲突、相对上游领先/落后为本地状态。

**升级前确认：0.5.0 需要同版本加密核心与新的 Compare 离线许可。** 仅升级薄插件不会让旧组件支持新日志，也不能让 0.4.x 授权打开新核心。继续使用旧许可的用户请保留 0.4.1 插件与 0.4.0 组件。其他 PP 产品继续使用原有核心与许可，不要删除或覆盖。

- 通过 AIDE 市场安装 0.5.0 薄插件。已有安装先备份当前组件和服务配置，再按共享组件说明升级；保留设备身份与其他 PP 产品的加密核心。为 0.5.0 导出 Compare 设备申请，拿到匹配许可后再切换。未授权不运行核心。
- 工作区通过 `--compare-workspace` 配置。每个额外 Git 引用需在 AIDE 中添加并允许读取，再由宿主组件用一个 `--compare-reference` 显式授权对应本机目录（可重复）。不支持 SSH/SFTP、任意路径或符号链接逃逸。额外引用只支持目录浏览及 Git 操作。
- Mac Docker Desktop：使用标准同机挂载，将宿主 bridge 目录只读挂载为容器 `/run/pp-license`；在 Compare 设置启用「映射 Mac Docker Desktop 工作区」。工作区及引用都要可由 AIDE 映射到同一台 Mac。
- Git 需装在宿主；PDF 提取需 Python 3 和 pypdf。支持 macOS Apple Silicon、Linux ARM64/AMD64。
