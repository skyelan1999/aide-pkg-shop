'use strict';
const prepare=(...args)=>require('./compare-source.cjs')(...args);
const text={type:'string',maxLength:2048}, num={type:'integer',minimum:1}, flag={type:'boolean'};
const common={offset:{type:'integer',minimum:0,maximum:1000000},limit:{...num,maximum:2000}};
const file={left:text,right:text,ignoreWhitespace:flag,ignoreCase:flag,ignoreEOL:flag,context:{type:'integer',minimum:0,maximum:50},maxFileBytes:{...num,maximum:8388608},...common};
const git={repository:text,mode:{type:'string',enum:['head','working','staged','revisions']},base:text,target:text,mergeBase:{...flag,description:'Compare the common ancestor against target; revisions mode only'},path:text,...common};
const definitions=[
 ['status','Check the local read-only comparison engine and supported limits',{},[]],
 ['browse','List files and folders inside the selected Aide workspace or reference source; symlinks are not followed',{path:text,limit:{...num,maximum:5000}},['path']],
 ['images','Compare PNG/JPEG/GIF first-frame decoded RGBA pixels locally; return changed ratio and bounding box. No OCR or visual semantics',{left:text,right:text,threshold:{type:'integer',minimum:0,maximum:255},includePreview:{type:'boolean',description:'Return bounded JPEG thumbnails; false by default for AI calls'},maxFileBytes:file.maxFileBytes},['left','right']],
 ['documents','Compare extracted PDF/DOCX/XLSX/PPTX text and selected structure locally with page/paragraph/cell/slide positions. Excludes layout, pictures and OCR',{...file,maxUnits:{...num,maximum:20000}},['left','right']],
 ['files','Compare two files from selected Aide sources with bounded text alignment, binary hashes, encoding and EOL evidence',file,['left','right']],
 ['directories','Compare folders by streamed SHA-256 or explicitly limited metadata; incomplete scans never prove equality',{left:text,right:text,comparison:{type:'string',enum:['content','metadata']},exclude:{type:'array',items:{type:'string'},maxItems:64},maxFiles:{...num,maximum:20000},maxDepth:{...num,maximum:64},maxBytes:{...num,maximum:536870912},...common},['left','right']],
 ['git','Read Git changes, refs and rename paths without fetching, index updates or external filters',git,['repository']],
 ['git_refs','List local branches, cached remote-tracking branches and tags; optionally read Git log, commit details and local status without fetching',{repository:text,logOverview:flag,logRef:text,logCommit:text,limit:{...num,maximum:500}},['repository']],
 ['git_file','Compare one Git file between HEAD, index, worktree or two commits; auto-detect supported image/document formats',{...file,...git,oldPath:text,content:{type:'string',enum:['auto','text','images','documents']},includePreview:flag,threshold:{type:'integer',minimum:0,maximum:255},maxUnits:{...num,maximum:20000}},['repository','path']],
 ['read','Read a bounded original-file line window with one-based source line numbers',{path:text,maxFileBytes:file.maxFileBytes,...common},['path']],
 ['report','Recompute a comparison and return a report. review is an engine-authored technical HTML report; evidence is a bounded ZIP containing both original inputs and a standalone verifier. Evidence content is base64: prefer UI export to avoid large model tokens. No signature, trusted time or legal-admissibility claim; no workspace file is written',{format:{type:'string',enum:['json','markdown','html','review','evidence']},expectedComparisonId:{type:'string'},request:{type:'object',properties:{operation:{type:'string',enum:['files','directories','git','git_file','read','images','documents']},arguments:{type:'object'}},required:['operation','arguments'],additionalProperties:false}},['request']]
];
module.exports={name:'compare',apply(ctx){const prepareInScope=(...args)=>prepare(...args,ctx.settings);for(const [operation,description,originalProperties,required]of definitions){const source={type:'string',maxLength:80,description:'Aide source ID from compare_status: workspace, context, or source:<id>'};const properties={...originalProperties,...(!['status','report'].includes(operation)?{fileSource:source}:{}),...(['files','directories','images','documents'].includes(operation)?{leftSource:source,rightSource:source}:{})};ctx.tool({name:'compare_'+operation,description,parameters:{type:'object',properties,required,additionalProperties:false},handler:async(args={},api)=>{
 if(!api)throw Error('Aide tool API unavailable');
 if(!args||Array.isArray(args)||typeof args!=='object'||Object.keys(args).some(k=>!Object.hasOwn(properties,k)))throw Error('Unknown comparison arguments');
 let prepared;
 if(operation==='report'){
  if(!args.request||!['files','directories','git','git_file','read','images','documents'].includes(args.request.operation))throw Error('Invalid report request');
  prepared=await prepareInScope(args.request.operation,args.request.arguments||{},api);
  prepared.args={...args,request:{operation:args.request.operation,arguments:prepared.args}};
 }else prepared=await prepareInScope(operation,args,api);
 if(prepared.result)return prepared.result;
 const reply=await require('./offline-adapter.cjs').worker({operation,workspace:prepared.workspace,arguments:prepared.args});
 const data=typeof reply==='string'?JSON.parse(reply):reply;
 if(!data||data.ok!==true)throw Error(data?.error?.code+': '+(data?.error?.message||'Native comparison failed'));
 return {...data.result,...prepared.extra};
 }});}}};

const applyCompare=module.exports.apply;module.exports.apply=ctx=>{require('./offline-adapter.cjs').register(ctx,'compare','compare_license');return applyCompare(ctx);};
