# Compare · 专有商业版

通过 Aide 市场安装薄插件。需在本机安装匹配的共享离线授权组件、配置同机工作区，再导出设备申请并导入 .plicense。

获取报价、售后、问题反馈：business@sklastu.com
