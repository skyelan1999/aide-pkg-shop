'use strict';
const fs=require('node:fs');
const path=require('node:path');
module.exports=async function prepare(operation,args,api){
 if(!api?.sources)throw Error('Compare 商业版需要支持本地来源校验的 Aide');
 if(!args||typeof args!=='object'||Array.isArray(args)||Object.hasOwn(args,'sources'))throw Error('比较参数无效');
 for(const key of ['fileSource','leftSource','rightSource']){
  if(Object.hasOwn(args,key)&&args[key]!=='workspace')throw Error('Compare 商业版暂只支持同机工作区，不支持引用来源和 SSH/SFTP');
 }
 const root=await api.sources({operation:'localRoot',source:'workspace'});
 if(typeof root.workspace!=='string'||!path.isAbsolute(root.workspace)||typeof api.workspaceRoot!=='string'||!path.isAbsolute(api.workspaceRoot))throw Error('本机 Aide 工作区不可用');
 const workspace=fs.realpathSync(root.workspace);
 if(fs.realpathSync(api.workspaceRoot)!==workspace)throw Error('Aide 工作区已变化');
 const clean={...args};
 for(const selector of ['fileSource','leftSource','rightSource'])delete clean[selector];
 return {workspace,args:clean,extra:operation==='status'?{sources:[{id:'workspace',name:'工作区',type:'local'}]}:{}};
};
