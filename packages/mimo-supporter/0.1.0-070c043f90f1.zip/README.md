# MiMoSupporter

MiMoSupporter 为 Aide 提供小米 MiMo 的离线费率。带有 MiMo 账户适配的 Aide 还可查询账户余额和个人 Token Plan 套餐余量。项目使用 MIT 许可，由社区维护，与小米官方产品独立。

## 安装与使用

在 Aide 插件市场安装并启用 MiMoSupporter，或导入 GitHub Release 的 ZIP。使用费率需要 Aide 0.1.17.5 RC5 或更新版本中的 `providerSupport` 协议 1。余额和套餐余量需要具备 MiMo 账户适配的 Aide。各版本在现有的使用统计中显示宿主支持的数据。[GitHub Release](https://github.com/skyelan1999/aide-pkg-MiMoSupporter/releases)

进入「模型设置 → 添加提供商」，添加小米 MiMo 按量计费服务，使用 `https://api.xiaomimimo.com/v1` 和控制台发放的 `sk-` 密钥。Aide 按已配置的官方 HTTPS 地址与精确模型 ID 匹配费率。密钥保存在 Aide 的凭证库，由宿主使用。插件只提供声明档案。

## 中国区按量计费

截至 2026-11-19 的实时推理公开价格，单位为人民币／百万 Token。

| 模型 ID | 输入（未命中缓存） | 输入（命中缓存） | 输出 |
| --- | ---: | ---: | ---: |
| `mimo-v2.6-pro` | ¥3 | ¥0.025 | ¥6 |
| `mimo-v2.6-flash` | ¥1 | ¥0.02 | ¥2 |

估算以中国区实时推理刊例价为准。批量推理、海外计价、语音、搜索、定制模型和合同折扣请查小米账单。其他模型与代理端点沿用 Aide 的费率配置。价格快照随插件版本更新。[MiMo 批量与实时价格](https://mimo.mi.com/docs/zh-CN/quick-start/usage-guide/text-generation/batch-api)

## 账户余额与个人套餐余量

支持 MiMo 账户适配的 Aide 会在用户查询时向小米官方接口发出只读请求。按量账户按接口返回的币种显示余额。[账户余额接口](https://mimo.mi.com/docs/zh-CN/api/asset/balance-get)

个人 Token Plan 使用套餐页面提供的 OpenAI 兼容地址和 `tp-` 密钥。中国、新加坡和欧洲集群的套餐余量以 Credits 为单位。团队版请在小米控制台查看席位和额度。上表的人民币费率只适用于按量计费的实时推理。[个人套餐余量接口](https://mimo.mi.com/docs/zh-CN/api/asset/credits-get) · [Token Plan 接入](https://mimo.mi.com/docs/zh-CN/tokenplan/Token%20Plan/quick-access)

## 检查与打包

```sh
node --test test/catalog.test.cjs
python3 scripts/package.py
cd dist && shasum -a 256 -c SHA256SUMS
```

市场和 GitHub Release 使用同一份通用 ZIP。检查使用本地档案及合成数据。
