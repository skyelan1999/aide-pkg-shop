'use strict';

module.exports = {
  name: 'mimo-supporter',
  apply() {},
};
