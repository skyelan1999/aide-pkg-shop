'use strict';

const fs = require('node:fs'),
  path = require('node:path'),
  Core = require('./offline-adapter.cjs').core;
function relative(p) {
  if (typeof p !== 'string' || !p || p.length > 2048 || p.startsWith('/') || /[\\\x00-\x1f]/.test(p) || p !== '.' && p.split('/').some(x => !x || x === '.' || x === '..')) throw Error('请使用来源内相对路径');
  return p;
}
module.exports = {
  name: 'pp-customer',
  apply(ctx) {
    const tool = (name, description, properties, required, handler) => ctx.tool({
      name,
      description,
      parameters: {
        type: 'object',
        properties,
        required,
        additionalProperties: false
      },
      handler
    });
    tool('ppc_guide', 'PPCustomer 使用指南与文件说明。', {}, [], () => ({
      version: '0.2.0',
      readOnly: true,
      steps: ['打开一个 .pp，查看甘特图、风险与沟通', '在项目设置中选择显示范围、调整排期并填写汇报内容', '管理文件保存为 .ppcdraft；项目视图为 .ppc；可导出项目汇报'],
      boundary: ['项目视图使用严格字段白名单，不含原计划对照/内部排期调整记录/源路径/内部编号/预算/成本/人员清单/未显示风险/战略评分', '任务标题与手写说明仍须人工核对，字段白名单不替代内容审阅', '客户反馈与验收为离线记录，不是已发送消息或电子签名', '不能将本插件当作 Aide 工作区访问隔离；客户账号仍须配置独立工作区权限'],
      limits: {
        projects: 1,
        sourceFileBytes: 8388608,
        localUploadBytes: 131072
      }
    }));
    tool('ppc_sources', '列出或浏览已授权的工作区/引用，仅展示目录与 .pp 文件。', {
      fileSource: {
        type: 'string'
      },
      path: {
        type: 'string'
      },
      offset: {
        type: 'integer',
        minimum: 0,
        maximum: 5000
      }
    }, [], async (a, api) => {
      if (!api.sources) throw Error('当前宿主不支持来源读取，请更新 Aide');
      if (!a.fileSource) return api.sources({
        operation: 'sources'
      });
      const r = await api.sources({
        operation: 'browse',
        source: a.fileSource,
        path: relative(a.path || '.')
      });
      if (!Array.isArray(r.entries) || r.truncated) throw Error('目录列表不完整，请选择更小目录');
      const entries = r.entries.filter(e => e.kind === 'directory' || e.kind === 'file' && /\.pp$/i.test(e.path)).sort((a, b) => (a.kind === 'directory' ? 0 : 1) - (b.kind === 'directory' ? 0 : 1) || a.path.localeCompare(b.path));
      const offset = a.offset || 0;
      return {
        entries: entries.slice(offset, offset + 200),
        hasMore: offset + 200 < entries.length,
        total: entries.length
      };
    });
    tool('ppc_prepare', '只读解析一个 .pp（JSON 或 SQLite 封装），仅返回项目界面使用的计划与风险字段。默认无客户可见项，不返回成本、人员或内部修订记录。', {
      fileSource: {
        type: 'string'
      },
      path: {
        type: 'string'
      },
      name: {
        type: 'string'
      },
      contentBase64: {
        type: 'string',
        maxLength: 174764
      },
      asOf: {
        type: 'string'
      }
    }, ['asOf'], async (a, api) => {
      let data, source;
      if (a.path) {
        if (a.contentBase64) throw Error('文件路径与上传内容不能同时提供');
        if (!/\.pp$/i.test(relative(a.path))) throw Error('请选择 .pp 文件');
        if (!api.sources) throw Error('需要新版 Aide 文件来源能力');
        const staged = await api.sources({
          operation: 'stage',
          source: a.fileSource || 'workspace',
          path: a.path,
          slot: 'path',
          maxBytes: 8388608
        });
        const base = fs.realpathSync(staged.workspace),
          file = fs.realpathSync(path.resolve(base, staged.path));
        if (!file.startsWith(base + path.sep)) throw Error('文件快照路径越界');
        const stat = fs.lstatSync(file);
        if (!stat.isFile() || stat.size > 8388608) throw Error('不支持的文件容量');
        data = fs.readFileSync(file);
        source = {
          kind: 'source',
          source: a.fileSource || 'workspace',
          path: a.path
        };
      } else {
        if (typeof a.contentBase64 !== 'string' || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(a.contentBase64)) throw Error('上传内容无效');
        data = Buffer.from(a.contentBase64, 'base64');
        if (data.length > 131072) throw Error('本机直传上限 128 KiB；请将文件放入工作区/引用后打开，支持 8 MiB');
        source = {
          kind: 'upload',
          name: String(a.name || 'uploaded.pp').slice(0, 200)
        };
      }
      const raw = await require('./offline-adapter.cjs').worker({
        contentBase64: data.toString('base64'),
        asOf: a.asOf
      });
      const out = typeof raw === 'string' ? JSON.parse(raw) : raw;
      if (!out.ok) throw Error(out.error || '无法解析 .pp');
      return {
        ...out.result,
        source
      };
    });
    tool('ppc_validate', '严格校验已准备的 .ppc 项目视图字段白名单；不认证内容真实性或客户身份。', {
      pack: {
        type: 'object'
      }
    }, ['pack'], async a => {
      await Core.validatePack(a.pack);
      return {
        valid: true,
        projects: a.pack.projects.length,
        customer: a.pack.customer,
        notice: '结构检查通过；内容授权、身份和验收真实性须独立核实'
      };
    });
  }
};
const __businessApply=module.exports.apply;module.exports.apply=function(ctx){require('./offline-adapter.cjs').register(ctx,"pp-customer","ppc_license");return __businessApply(ctx);};
