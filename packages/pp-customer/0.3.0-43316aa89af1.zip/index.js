'use strict';

const fs = require('node:fs'),
  path = require('node:path'),
  Core = require('./offline-adapter.cjs').core,
  R = {
    html: async (...args) => (await require('./offline-adapter.cjs').coreCall('report.js', 'html', args)).value,
    markdown: async (...args) => (await require('./offline-adapter.cjs').coreCall('report.js', 'markdown', args)).value
  };
const store = require('./project-store.cjs').service();
const GUIDE = fs.readFileSync(path.join(__dirname, 'AI-GUIDE.md'), 'utf8');
function relative(p) {
  if (typeof p !== 'string' || !p || p.length > 2048 || p.startsWith('/') || /[\\\x00-\x1f]/.test(p) || p !== '.' && p.split('/').some(x => !x || x === '.' || x === '..')) throw Error('请使用来源内相对路径');
  return p;
}
async function engine(args, api) {
  const raw = await require('./offline-adapter.cjs').worker(args);
  const out = typeof raw === 'string' ? JSON.parse(raw) : raw;
  if (!out.ok) throw Error(out.error || '无法处理 .pp');
  return out.result;
}
function stagedFile(staged) {
  const root = fs.realpathSync(staged.workspace),
    file = fs.realpathSync(path.resolve(root, staged.path));
  if (!file.startsWith(root + path.sep) || !fs.lstatSync(file).isFile()) throw Error('文件快照路径无效');
  return file;
}
async function currentBinding(a, api) {
  const binding = await store({
    action: 'binding'
  }, api);
  if (!binding) throw Error('请先从工作区或引用打开 .pp，才能直接自动保存');
  if (a.projectId && binding.projectId !== a.projectId) throw Error('当前绑定项目不同，请重新读取当前 .pp');
  return binding;
}
async function readBound(a, api, head = false) {
  const binding = await currentBinding(a, api),
    staged = await api.sources({
      operation: 'stage',
      source: binding.fileSource,
      path: binding.path,
      slot: 'path',
      maxBytes: 8388608
    }),
    raw = fs.readFileSync(stagedFile(staged)),
    revision = require('node:crypto').createHash('sha256').update(raw).digest('hex');
  if (head) return {
    projectId: binding.projectId,
    revision
  };
  const c = await engine({
    contentBase64: raw.toString('base64'),
    asOf: new Date().toLocaleDateString('en-CA', {
      timeZone: 'Asia/Shanghai'
    })
  }, api);
  let data = c.savedDraft ? (await Core.openProjectFile(c.savedDraft)).data : await Core.fresh();
  if (!c.savedDraft) data.id = binding.projectId;
  await Core.mergeDraft(data, c, {
    kind: 'source',
    source: binding.fileSource,
    path: binding.path
  }, true);
  return {
    data,
    editable: true,
    revision,
    savedAt: c.savedDraft?.savedAt || '',
    binding
  };
}
async function saveBound(document, expectedRevision, api, review = false) {
  const opened = await Core.openProjectFile(document);
  if (!opened.editable) throw Error('.ppc 预览不能覆盖 .pp 设置');
  const binding = await currentBinding({
    projectId: opened.data.id
  }, api);
  if (!/^[a-f0-9]{64}$/.test(expectedRevision || '')) throw Error('需要原 .pp 的版本摘要');
  const staged = await api.sources({
    operation: 'checkout',
    source: binding.fileSource,
    path: binding.path,
    slot: 'save',
    write: true,
    allowCreate: false
  });
  const file = stagedFile(staged),
    raw = fs.readFileSync(file);
  if (require('node:crypto').createHash('sha256').update(raw).digest('hex') !== expectedRevision) throw Error('原 .pp 版本冲突：PP 或其他窗口已更新。请重新读取，本地修改仍保留');
  if (!review) {
    const candidate = await engine({
        contentBase64: raw.toString('base64'),
        asOf: new Date().toLocaleDateString('en-CA', {
          timeZone: 'Asia/Shanghai'
        })
      }, api),
      before = candidate.savedDraft ? (await Core.openProjectFile(candidate.savedDraft)).data : await Core.fresh();
    await Core.mergeDraft(before, candidate, {
      kind: 'source',
      source: binding.fileSource,
      path: binding.path
    }, true);
    await Core.assertSettingsUpdate(before, opened.data);
  }
  const result = await engine({
    operation: 'save_customer',
    contentBase64: raw.toString('base64'),
    draft: opened.data
  }, api);
  const bytes = Buffer.from(result.contentBase64, 'base64');
  if (bytes.length > 8388608 || require('node:crypto').createHash('sha256').update(bytes).digest('hex') !== result.sha256) throw Error('更新后的 .pp 内容校验失败');
  fs.writeFileSync(file, bytes);
  const committed = await api.sources({
    operation: 'commit',
    slot: 'save'
  });
  if (committed.saved !== true || committed.hash !== result.sha256) throw Error('宿主未确认 .pp 保存结果，请重新读取核对');
  return {
    saved: true,
    revision: result.sha256,
    savedAt: new Date().toISOString(),
    location: 'source-pp',
    extension: '.pp'
  };
}
module.exports = {
  name: 'pp-customer',
  apply(ctx) {
    const tool = (name, description, properties, required, handler) => ctx.tool({
      name,
      description,
      parameters: {
        type: 'object',
        properties,
        required,
        additionalProperties: false
      },
      handler
    });
    tool('ppc_guide', 'PPCustomer 操作协议与提示词。首次控制 PPCustomer 必读；区分待审批预览和正式排期。', {}, [], () => ({
      version: '0.3.0',
      protocol: 2,
      instructions: GUIDE,
      limits: {
        projects: 1,
        sourceFileBytes: 8388608,
        localUploadBytes: 131072
      },
      defaultSelection: 'milestones-only',
      projectExtension: '.ppc',
      autosave: 'source-pp'
    }));
    tool('ppc_sources', '列出或浏览已授权的工作区/引用，仅展示目录与 .pp 文件。', {
      fileSource: {
        type: 'string'
      },
      path: {
        type: 'string'
      },
      offset: {
        type: 'integer',
        minimum: 0,
        maximum: 5000
      }
    }, [], async (a, api) => {
      if (!api.sources) throw Error('当前宿主不支持来源读取，请更新 Aide');
      if (!a.fileSource) return api.sources({
        operation: 'sources'
      });
      const r = await api.sources({
        operation: 'browse',
        source: a.fileSource,
        path: relative(a.path || '.')
      });
      if (!Array.isArray(r.entries) || r.truncated) throw Error('目录列表不完整，请选择更小目录');
      const entries = r.entries.filter(e => e.kind === 'directory' || e.kind === 'file' && /\.pp$/i.test(e.path)).sort((a, b) => (a.kind === 'directory' ? 0 : 1) - (b.kind === 'directory' ? 0 : 1) || a.path.localeCompare(b.path));
      const offset = a.offset || 0;
      return {
        entries: entries.slice(offset, offset + 200),
        hasMore: offset + 200 < entries.length,
        total: entries.length
      };
    });
    tool('ppc_prepare', '只读解析一个 .pp（JSON 或 SQLite 封装），仅返回项目界面使用的计划与风险字段。默认无客户可见项，不返回成本、人员或内部修订记录。', {
      fileSource: {
        type: 'string'
      },
      path: {
        type: 'string'
      },
      name: {
        type: 'string'
      },
      contentBase64: {
        type: 'string',
        maxLength: 174764
      },
      asOf: {
        type: 'string'
      }
    }, ['asOf'], async (a, api) => {
      let data, source;
      if (a.path) {
        if (a.contentBase64) throw Error('文件路径与上传内容不能同时提供');
        if (!/\.pp$/i.test(relative(a.path))) throw Error('请选择 .pp 文件');
        if (!api.sources) throw Error('需要新版 Aide 文件来源能力');
        const staged = await api.sources({
          operation: 'stage',
          source: a.fileSource || 'workspace',
          path: a.path,
          slot: 'path',
          maxBytes: 8388608
        });
        const base = fs.realpathSync(staged.workspace),
          file = fs.realpathSync(path.resolve(base, staged.path));
        if (!file.startsWith(base + path.sep)) throw Error('文件快照路径越界');
        const stat = fs.lstatSync(file);
        if (!stat.isFile() || stat.size > 8388608) throw Error('不支持的文件容量');
        data = fs.readFileSync(file);
        source = {
          kind: 'source',
          source: a.fileSource || 'workspace',
          path: a.path
        };
      } else {
        if (typeof a.contentBase64 !== 'string' || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(a.contentBase64)) throw Error('上传内容无效');
        data = Buffer.from(a.contentBase64, 'base64');
        if (data.length > 131072) throw Error('本机直传上限 128 KiB；请将文件放入工作区/引用后打开，支持 8 MiB');
        source = {
          kind: 'upload',
          name: String(a.name || 'uploaded.pp').slice(0, 200)
        };
      }
      const result = await engine({
        contentBase64: data.toString('base64'),
        asOf: a.asOf
      }, api);
      let draft = result.savedDraft ? (await Core.openProjectFile(result.savedDraft)).data : await Core.fresh();
      await Core.mergeDraft(draft, result, source, true);
      if (source.kind === 'source') await store({
        action: 'bind',
        binding: {
          fileSource: source.source,
          path: source.path,
          projectId: draft.id
        }
      }, api);
      return {
        ...result,
        source,
        draft,
        revision: require('node:crypto').createHash('sha256').update(data).digest('hex'),
        canSave: source.kind === 'source'
      };
    });
    tool('ppc_validate', '严格校验已准备的 .ppc 项目视图字段白名单；不认证内容真实性或客户身份。', {
      pack: {
        type: 'object'
      }
    }, ['pack'], async a => {
      await Core.validatePack(a.pack);
      return {
        valid: true,
        projects: a.pack.projects.length,
        customer: a.pack.customer,
        notice: '结构检查通过；内容授权、身份和验收真实性须独立核实'
      };
    });
    const projectId = {
        type: 'string',
        maxLength: 120
      },
      revision = {
        type: 'string',
        pattern: '^[a-f0-9]{64}$'
      },
      text = {
        type: 'string',
        maxLength: 2000
      };
    async function loaded(a, api) {
      return await readBound(a, api);
    }
    async function persist(current, data, api, review = false) {
      return await saveBound(await Core.projectFile(data), current.revision, api, review);
    }
    tool('ppc_project', '当前 .pp 中的 PPCustomer 设置、申请与审批。get/head 读取，save 自动写回同一个 .pp；检查来源权限和版本冲突。.ppc 只用于对外可见内容快速预览。', {
      action: {
        type: 'string',
        enum: ['get', 'head', 'save', 'begin', 'chunk', 'commit', 'abort', 'compute']
      },
      projectId,
      document: {
        type: 'object'
      },
      expectedRevision: {
        type: 'string',
        maxLength: 64
      },
      uploadId: {
        type: 'string',
        maxLength: 48
      },
      totalBytes: {
        type: 'integer',
        minimum: 1,
        maximum: 16777216
      },
      offset: {
        type: 'integer',
        minimum: 0
      },
      chunk: {
        type: 'string',
        maxLength: 90000
      }
    }, ['action'], async (a, api) => {
      if (['begin', 'chunk', 'abort'].includes(a.action)) return store(a, api);
      if (a.action === 'compute') {
        try {
          const staged = await store({
              ...a,
              action: 'uploaded'
            }, api),
            packet = staged.document;
          if (packet.format !== 'ppc-core-call' || !Array.isArray(packet.data?.args) || packet.data.args.length > 8) throw Error('分段计算输入无效');
          const {
              module,
              method,
              args
            } = packet.data,
            allowed = ['fresh', 'validatePack', 'validateDraft', 'candidate', 'buildPack', 'mergeDraft', 'stats', 'brief', 'localView', 'previewView', 'changeSchedule', 'requestChange', 'reviewChange', 'resetSchedule', 'addPhase', 'deletePhase', 'projectFile', 'openProjectFile', 'assertSettingsUpdate'];
          let value;
          if (module === 'core.js' && allowed.includes(method)) value = await Core[method](...args);else if (module === 'report.js' && ['html', 'markdown'].includes(method)) value = await R[method](...args);else throw Error('分段计算方法不受支持');
          return {
            value,
            ...(['merge', 'mergeDraft'].includes(method) ? {
              args
            } : {})
          };
        } finally {
          await store({
            ...a,
            action: 'abort'
          }, api);
        }
      }
      if (a.action === 'commit') {
        const staged = await store({
          ...a,
          action: 'uploaded'
        }, api);
        const saved = await saveBound(staged.document, staged.expectedRevision, api);
        await store({
          ...a,
          action: 'abort'
        }, api);
        return saved;
      }
      if (a.action === 'save') return await saveBound(a.document, a.expectedRevision, api);
      if (a.action === 'head') return await readBound(a, api, true);
      return await loaded(a, api);
    });
    tool('ppc_inspect', '读取当前 PPCustomer 项目的事项、层级、已批准日期、待审批申请与版本摘要。默认仅已勾选里程碑；includeHidden=true 查看设置中的全部事项。只读。', {
      projectId,
      includeHidden: {
        type: 'boolean'
      }
    }, [], async (a, api) => {
      const x = await loaded(a, api),
        p = x.data.projects[0];
      return {
        projectId: x.data.id,
        revision: x.revision,
        title: x.data.title,
        editable: x.editable,
        items: p.items.filter(t => a.includeHidden || !x.editable || t.selected).map(t => ({
          id: t.id,
          title: t.title,
          kind: t.kind,
          parentId: t.parentId || null,
          start: t.start,
          finish: t.finish,
          percentComplete: t.percentComplete,
          selected: x.editable ? t.selected : true
        })),
        requests: x.editable ? p.scheduleRequests || [] : [],
        notice: 'items 是已批准内容；pending 仅影响预览，不能报告为已生效'
      };
    });
    tool('ppc_request_change', '提交任务名称或排期变更申请并自动保存；正式内容保持不变，工作台预览会先更新。需要从 ppc_inspect 取得事项 ID 与最新 revision，禁止按模糊名称猜测。', {
      projectId,
      expectedRevision: revision,
      itemId: {
        type: 'string',
        maxLength: 120
      },
      patch: {
        type: 'object',
        properties: {
          title: {
            type: 'string',
            maxLength: 500
          },
          start: {
            type: 'string'
          },
          finish: {
            type: 'string'
          }
        },
        additionalProperties: false
      },
      reason: text
    }, ['expectedRevision', 'itemId', 'patch', 'reason'], async (a, api) => {
      const x = await loaded(a, api);
      if (x.revision !== a.expectedRevision) throw Error('项目版本冲突，请重新 inspect');
      if (!x.editable) throw Error('共享视图不可发起排期申请，请打开可编辑项目');
      const next = await Core.requestChange(x.data, x.data.projects[0].id, a.itemId, a.patch, a.reason),
        saved = await persist(x, next, api),
        request = next.projects[0].scheduleRequests.at(-1);
      return {
        ...saved,
        request,
        status: 'pending',
        effective: false,
        notice: '已提交变更申请，尚未批准；视图仅预览'
      };
    });
    tool('ppc_review_change', '批准或驳回待审批申请。仅在用户明确要求批准/驳回该申请时调用；confirm=true 不代替用户指令。批准前核对申请前后日期与版本；settings 中也可人工审批。', {
      projectId,
      expectedRevision: revision,
      requestId: {
        type: 'string',
        maxLength: 120
      },
      decision: {
        type: 'string',
        enum: ['approve', 'reject']
      },
      reviewer: {
        type: 'string',
        maxLength: 200
      },
      note: text,
      confirm: {
        type: 'boolean'
      }
    }, ['expectedRevision', 'requestId', 'decision', 'reviewer', 'confirm'], async (a, api) => {
      if (a.confirm !== true) throw Error('需要明确确认审批操作');
      const x = await loaded(a, api);
      if (x.revision !== a.expectedRevision) throw Error('项目版本冲突，请重新 inspect');
      if (!x.editable) throw Error('共享视图不能审批');
      const next = await Core.reviewChange(x.data, x.data.projects[0].id, a.requestId, a.decision, a.reviewer, a.note || ''),
        saved = await persist(x, next, api, true);
      return {
        ...saved,
        request: next.projects[0].scheduleRequests.find(r => r.id === a.requestId),
        effective: a.decision === 'approve',
        notice: a.decision === 'approve' ? '申请已批准，正式排期已更新' : '申请已驳回，正式排期未改变'
      };
    });
    tool('ppc_report', '按已批准内容生成客户项目汇报或共享 .ppc，待审批预览不进入汇报。返回文本及 suggestedFilename；生成不等于保存文件。', {
      projectId,
      format: {
        type: 'string',
        enum: ['markdown', 'html', 'ppc']
      }
    }, ['format'], async (a, api) => {
      const x = await loaded(a, api),
        view = x.editable ? await Core.localView(x.data) : x.data;
      if (a.format === 'ppc') return {
        content: JSON.stringify(view, null, 2),
        suggestedFilename: 'PPCustomer-共享视图.ppc',
        saved: false,
        basis: 'approved'
      };
      const content = a.format === 'html' ? await R.html(view) : await R.markdown(view);
      return {
        content,
        suggestedFilename: 'PPCustomer-汇报.' + (a.format === 'html' ? 'html' : 'md'),
        saved: false,
        basis: 'approved'
      };
    });
  }
};
const __businessApply=module.exports.apply;module.exports.apply=function(ctx){require('./offline-adapter.cjs').register(ctx,"pp-customer","ppc_license");return __businessApply(ctx);};
