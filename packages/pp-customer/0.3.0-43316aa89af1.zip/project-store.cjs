'use strict';
// Workspace-scoped local project persistence. This never writes the source .pp.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const MAX=16*1024*1024,ID=/^[a-zA-Z0-9_-]{1,120}$/;
function directory(dir){fs.mkdirSync(dir,{mode:0o700,recursive:true});if(fs.lstatSync(dir).isSymbolicLink()||!fs.lstatSync(dir).isDirectory()||fs.realpathSync(dir)!==path.resolve(dir))throw Error('项目保存目录无效');fs.chmodSync(dir,0o700);return dir;}
function read(file,max=MAX){const fd=fs.openSync(file,fs.constants.O_RDONLY|(fs.constants.O_NOFOLLOW||0));try{const stat=fs.fstatSync(fd);if(!stat.isFile()||stat.nlink!==1||stat.size>max)throw Error('项目文件无效或过大');return fs.readFileSync(fd);}finally{fs.closeSync(fd);}}
const hash=raw=>crypto.createHash('sha256').update(raw).digest('hex');
function atomic(file,raw){const tmp=path.join(path.dirname(file),'.tmp-'+crypto.randomBytes(16).toString('hex'));try{fs.writeFileSync(tmp,raw,{mode:0o600,flag:'wx'});fs.renameSync(tmp,file);}finally{try{fs.unlinkSync(tmp);}catch{}}}
async function scope(api){if(api.sources){const info=await api.sources({operation:'sources'}),w=info.sources?.find(s=>s.id==='workspace');if(w?.workspaceKey)return String(w.workspaceKey);}if(api.workspaceRoot&&path.isAbsolute(api.workspaceRoot))return 'local:'+fs.realpathSync(api.workspaceRoot);throw Error('无法确认当前工作区，未自动保存');}
function service(base=path.join(__dirname,'..','.ppcustomer-projects')){return async function(a,api){
 const dir=directory(path.join(directory(base),hash(await scope(api))));
 const id=value=>{if(!ID.test(value||''))throw Error('项目编号无效');return value;};
 if(a.action==='binding'){try{return JSON.parse(read(path.join(dir,'active.json'),8192));}catch(e){if(e.code==='ENOENT')return null;throw e;}}
 if(a.action==='bind'){const b=a.binding;if(!b||!ID.test(b.projectId)||!/^workspace$|^context$|^source:[A-Za-z0-9_-]{1,64}$/.test(b.fileSource)||typeof b.path!=='string'||!b.path.toLowerCase().endsWith('.pp')||b.path.startsWith('/')||/[\\\x00-\x1f]/.test(b.path)||b.path.split('/').some(x=>!x||x==='.'||x==='..'))throw Error('原 .pp 来源绑定无效');atomic(path.join(dir,'active.json'),JSON.stringify(b));return {bound:true};}
 const uploadId=value=>{if(!/^[a-f0-9]{48}$/.test(value||''))throw Error('分段保存编号无效');return value;};
 function upload(value){const key=uploadId(value),meta=JSON.parse(read(path.join(dir,'upload-'+key+'.json'),2048));if(Date.now()-meta.createdAt>600000)throw Error('分段保存已过期，请重新保存');return {key,meta,file:path.join(dir,'upload-'+key+'.bin')};}
 if(a.action==='begin'){id(a.projectId);if(!Number.isInteger(a.totalBytes)||a.totalBytes<1||a.totalBytes>MAX||typeof a.expectedRevision!=='string')throw Error('分段保存参数无效');let count=0;for(const name of fs.readdirSync(dir)){if(!/^upload-[a-f0-9]{48}\.json$/.test(name))continue;const meta=JSON.parse(read(path.join(dir,name),2048));if(Date.now()-meta.createdAt>600000){fs.unlinkSync(path.join(dir,name));try{fs.unlinkSync(path.join(dir,name.replace('.json','.bin')));}catch{}}else count++;}if(count>=4)throw Error('分段保存过多，请稍后重试');const key=crypto.randomBytes(24).toString('hex');atomic(path.join(dir,'upload-'+key+'.json'),JSON.stringify({projectId:a.projectId,expectedRevision:a.expectedRevision,totalBytes:a.totalBytes,createdAt:Date.now()}));fs.writeFileSync(path.join(dir,'upload-'+key+'.bin'),'',{flag:'wx',mode:0o600});return {uploadId:key};}
 if(a.action==='chunk'){const u=upload(a.uploadId);if(typeof a.chunk!=='string'||a.chunk.length>90000||!/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(a.chunk))throw Error('分段内容无效');const data=Buffer.from(a.chunk,'base64');if(!data.length||data.length>65536||!Number.isInteger(a.offset))throw Error('分段长度无效');const fd=fs.openSync(u.file,fs.constants.O_WRONLY|fs.constants.O_APPEND|(fs.constants.O_NOFOLLOW||0));try{const st=fs.fstatSync(fd);if(!st.isFile()||st.nlink!==1||st.size!==a.offset||st.size+data.length>u.meta.totalBytes)throw Error('分段偏移或大小不匹配，请重新保存');fs.writeSync(fd,data);}finally{fs.closeSync(fd);}return {received:a.offset+data.length};}
 if(a.action==='uploaded'){const u=upload(a.uploadId),raw=read(u.file);if(raw.length!==u.meta.totalBytes)throw Error('分段保存不完整');const document=JSON.parse(raw);if(document.data?.id!==u.meta.projectId)throw Error('项目编号与分段申请不匹配');return {document,expectedRevision:u.meta.expectedRevision};}
 if(a.action==='abort'){const u=upload(a.uploadId);fs.unlinkSync(u.file);fs.unlinkSync(path.join(dir,'upload-'+u.key+'.json'));return {aborted:true};}
 throw Error('项目元数据操作无效');
};}
module.exports={service};
