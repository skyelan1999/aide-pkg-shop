'use strict';
// Generic offline presentation of an already validated, customer-visible snapshot.
// Approval, selection and licensing are enforced by the caller, before rendering.
const fs=require('node:fs'),path=require('node:path');
const PDFDocument=require('./vendor/pdf/pdfkit.cjs');
const MAX_BYTES=16*1024*1024,MAX_PAGES=256;
async function render(view,stats){
 if(!view?.projects?.[0])throw Error('请先打开一个客户项目再导出 PDF');
 const project=view.projects[0],font=fs.readFileSync(path.join(__dirname,'vendor/pdf/NotoSansSC-Regular.otf'));
 const doc=new PDFDocument({autoFirstPage:false,size:'A4',layout:'landscape',margin:36,bufferPages:true,compress:true,info:{Title:project.title+' · 项目汇报',Author:view.contact||'PPCustomer',Subject:'已批准的客户项目进度、排期与沟通',Creator:'PPCustomer'}});
 const chunks=[];let size=0,pages=0,y=0,ended=false;
 const finished=new Promise((resolve,reject)=>{doc.on('data',b=>{size+=b.length;if(size>MAX_BYTES)doc.destroy(Error('PDF 超过 16 MiB，请缩小项目可见范围后重试'));else chunks.push(b);});doc.once('error',reject);doc.once('end',()=>resolve(Buffer.concat(chunks)));});
 // Install the rejection handler before any synchronous rendering can fail.
 finished.catch(()=>{});
 try{
  doc.registerFont('Report',font);doc.font('Report');
  const W=841.89,H=595.28,L=36,R=W-36,CW=R-L,BOTTOM=H-44;
  const ink='#25342e',muted='#65716b',line='#dbe1dc',accent='#3e705e',warn='#a67620';
  const widths=new Map(),glyphs=new Map();
  function clean(value){let out='';for(const c of String(value??'').replace(/\r\n?/g,'\n').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g,'')){if(c==='\n'||c==='\t'){out+=c==='\t'?'  ':c;continue;}let supported=glyphs.get(c);if(supported===undefined){supported=doc._font.font.hasGlyphForCodePoint(c.codePointAt(0));glyphs.set(c,supported);}out+=supported?c:'[U+'+c.codePointAt(0).toString(16).toUpperCase()+']';}return out;}
  function width(c,size){const key=size+'|'+c;if(!widths.has(key))widths.set(key,doc.fontSize(size).widthOfString(c));return widths.get(key);}
  function wrap(value,w,size){const result=[];let current='',used=0;for(const c of clean(value)){if(c==='\n'){result.push(current);current='';used=0;continue;}const next=width(c,size);if(current&&used+next>w){result.push(current);current='';used=0;}current+=c;used+=next;}result.push(current);return result;}
  function short(value,w,size){const lines=wrap(value,w,size);if(lines.length===1)return lines[0];let text=lines[0];while(text&&doc.fontSize(size).widthOfString(text+'…')>w)text=text.slice(0,-1);return text+'…';}
  function text(value,x,at,size=10,color=ink,w=CW){doc.font('Report').fontSize(size).fillColor(color).text(clean(value),x,at,{width:w,height:size*1.8,lineBreak:false});}
  function newPage(){if(++pages>MAX_PAGES)throw Error('PDF 超过 256 页，请缩小项目可见范围');doc.addPage();text('PPCustomer · 项目汇报',L,20,8,muted,180);text(short(project.title,CW-200,8),L+200,20,8,muted,CW-200);doc.moveTo(L,37).lineTo(R,37).lineWidth(.5).strokeColor(line).stroke();y=52;}
  function need(height){if(y+height>BOTTOM)newPage();}
  function paragraph(value,size=10,color=ink){const rows=wrap(value||'暂无记录',CW,size),step=size+5;for(const row of rows){need(step);text(row,L,y,size,color);y+=step;}y+=6;}
  function heading(value){need(64);y+=8;text(value,L,y,14,accent);y+=25;}
  function label(value){need(45);text(value,L,y,10,accent);y+=18;}
  function rule(){need(8);doc.moveTo(L,y).lineTo(R,y).strokeColor(line).lineWidth(.4).stroke();y+=9;}
  function period(value,end=false){let m;if((m=/^(\d{4})-(\d{2})-(\d{2})$/.exec(value||'')))return Date.UTC(+m[1],+m[2]-1,+m[3]);if((m=/^(\d{4})-(\d{2})$/.exec(value||'')))return end?Date.UTC(+m[1],+m[2],0):Date.UTC(+m[1],+m[2]-1,1);if((m=/^(\d{4})-W(\d{2})$/.exec(value||''))){const fourth=Date.UTC(+m[1],0,4),day=new Date(fourth).getUTCDay()||7;return fourth+(1-day+(+m[2]-1)*7+(end?6:0))*86400000;}return null;}
  newPage();
  for(const row of wrap(project.title+' · 项目汇报',CW,23)){need(32);text(row,L,y,23);y+=32;}
  paragraph(view.customer||'项目协作',11,muted);
  paragraph(view.report?.from&&view.report?.to?'汇报期间：'+view.report.from+' 至 '+view.report.to:'截至：'+String(view.publishedAt).slice(0,10),9,muted);
  paragraph('本汇报采用已批准内容；待审批变更不进入正式排期。',9,muted);
  need(62);const metricWidth=(CW-30)/4;
  for(const [i,[title,value]] of [['计划进度',stats.progress===null?'未显示':stats.progress+'%'],['计划事项',stats.items],['待跟进风险',stats.risks],['待回复沟通',stats.feedback]].entries()){const x=L+i*(metricWidth+10);doc.roundedRect(x,y,metricWidth,53,5).lineWidth(.6).strokeColor(line).stroke();text(title,x+12,y+8,9,muted,metricWidth-24);text(String(value),x+12,y+23,18,ink,metricWidth-24);}y+=64;
  heading('一、项目概况');paragraph(view.report?.summary||project.summary);label('本期完成');paragraph(view.report?.achievements);label('下一步安排');paragraph(view.report?.nextSteps);
  const items=project.items||[],dates=items.flatMap(t=>[period(t.start),period(t.finish,true)]).filter(Number.isFinite),lo=dates.length?Math.min(...dates):null,hi=dates.length?Math.max(...dates):null;
  const tx=L+260,tw=CW-260,span=Math.max(86400000,(hi||0)-(lo||0));
  for(let start=0;start<items.length;start+=17){newPage();heading('二、项目甘特图 · '+(Math.floor(start/17)+1)+' / '+Math.ceil(items.length/17));paragraph('◆ 里程碑 · 绿色表示已完成进度，浅色表示计划排期；完整名称与日期见后续明细。',8,muted);const top=y;doc.rect(L,top,CW,27).fill('#f0f4f1');text('事项 / 进度',L+8,top+8,9,muted,245);if(lo!==null)for(let i=0;i<=5;i++){const x=tx+6+(tw-20)*i/5,date=new Date(lo+span*i/5).toISOString().slice(0,10);text(date,i===5?x-47:x+3,top+9,7,muted,67);}y+=27;
   for(const t of items.slice(start,start+17)){const row=y;doc.moveTo(L,row+24).lineTo(R,row+24).lineWidth(.4).strokeColor(line).stroke();text(short((t.kind==='milestone'?'◆ ':'')+t.title,215,9),L+8,row+7,9,ink,220);text(t.percentComplete===null?'':t.percentComplete+'%',L+226,row+7,8,muted,30);
    for(let i=0;i<=5;i++){const x=tx+6+(tw-20)*i/5;doc.moveTo(x,row).lineTo(x,row+24).strokeColor('#e7ebe8').lineWidth(.35).stroke();}
    const a=period(t.start),b=period(t.finish,true);if(a!==null&&b!==null&&lo!==null){const x=tx+6+(a-lo)/span*(tw-20),end=tx+6+(b-lo)/span*(tw-20);if(t.kind==='milestone'){const center=Math.min(R-7,Math.max(tx+7,x));doc.save().translate(center,row+12).rotate(45).rect(-4,-4,8,8).fill(t.percentComplete===100?accent:warn).restore();}else{const barWidth=Math.max(4,Math.min(R-5,end)-x);doc.roundedRect(x,row+8,barWidth,9,2).fill('#d9e6df');if(t.percentComplete>0)doc.rect(x,row+8,barWidth*t.percentComplete/100,9).fill(accent);}}else text('日期待定',tx+8,row+7,8,muted,tw-16);y+=24;
   }
  }
  newPage();heading('三、排期明细');if(!items.length)paragraph('暂无排期事项');
  for(const [i,t]of items.entries()){const rows=wrap((i+1)+'. '+(t.kind==='milestone'?'◆ ':'')+t.title,CW,10);need(rows.length*15+27);for(const row of rows){text(row,L,y,10);y+=15;}text('开始：'+(t.start||'待定')+'     完成：'+(t.finish||'待定')+'     进度：'+(t.percentComplete===null?'未显示':t.percentComplete+'%'),L+10,y,9,muted,CW-10);y+=25;}
  heading('四、风险事项');const levels={high:'高风险',medium:'中风险',low:'低风险'},riskStates={open:'待处理',mitigating:'处理中',closed:'已关闭'};
  if(!project.risks?.length)paragraph('暂无已记录的风险事项');
  for(const r of project.risks||[]){label(levels[r.level]+' / '+riskStates[r.status]);paragraph(r.title,11);if(r.impact)paragraph('影响：'+r.impact);if(r.mitigation)paragraph('应对：'+r.mitigation);if(r.owner||r.due)paragraph([r.owner?'负责人：'+r.owner:'',r.due?'跟进日期：'+r.due:''].filter(Boolean).join(' · '),9,muted);rule();}
  heading('五、沟通记录');if(!view.feedback?.length)paragraph('暂无沟通记录');for(const f of view.feedback||[]){label(f.author+' · '+String(f.at).slice(0,10));paragraph(f.body);if(f.reply)paragraph('回复 / 约定：'+f.reply);else paragraph('待跟进',9,muted);rule();}
  if(project.deliverables?.length){heading('六、交付确认');for(const d of project.deliverables){label(d.title);paragraph('计划日期：'+(d.due||'待定')+' · '+({planned:'准备中',submitted:'待确认',accepted:'已确认',changes:'需调整'}[d.status]||d.status));if(d.criteria)paragraph('确认标准：'+d.criteria);if(d.reference)paragraph('参考：'+d.reference);if(d.acceptedBy)paragraph('确认人：'+d.acceptedBy+' · '+(d.acceptedAt||''));if(d.note)paragraph(d.note);rule();}}
  if(project.updates?.length){heading('项目动态');for(const u of project.updates){label(u.title+' · '+u.date);paragraph(u.text);}}
  paragraph(view.contact||'PPCustomer 项目汇报',9,muted);paragraph('生成时间：'+String(view.publishedAt).slice(0,19).replace('T',' ')+' UTC',8,muted);
  const range=doc.bufferedPageRange();for(let i=range.start;i<range.start+range.count;i++){doc.switchToPage(i);doc.moveTo(L,H-34).lineTo(R,H-34).lineWidth(.4).strokeColor(line).stroke();text('第 '+(i+1)+' 页 / 共 '+range.count+' 页',L,H-26,8,muted,CW);}
  doc.end();ended=true;const bytes=await finished;if(bytes.subarray(0,5).toString()!=='%PDF-')throw Error('PDF 生成结果无效');return bytes;
 }catch(e){if(!ended)doc.destroy();throw e;}
}
module.exports={render};
