'use strict';
// Native-backed plugin: the Go workflow owns workspace identity, SSH and
// source permissions. This entrypoint supplies the standard plugin surface.
module.exports = {
  name: 'office',
  apply(ctx) {
    ctx.tool({name:"office_document_search",description:"原文搜索或RAG片段检索，复用星图文档服务。original逐字匹配提取原文，rag本地TF-IDF片段排序（非向量）。返回文件指纹、片段编号及页/段落/工作表/幻灯片定位；只读，无OCR，不代表全文已读。支持本地/SSH工作区及已启用的文件来源；MCP仅检索已发现工具说明，不自动调用工具。",parameters:{type:"object",required:["query","mode"],properties:{query:{type:"string"},mode:{type:"string",enum:["original","rag"]},source:{type:"string"},path:{type:"string"},cursor:{type:"string",description:"上一结果的 nextCursor；保持 query、mode、source、path 不变，继续检查下一批"}}},handler(){throw new Error("office_document_search 必须由 aide 原生工作区执行器调用");}});
    ctx.tool({name:'office_document_read',description:'分页读取 DOCX/XLSX/PPTX 的可定位文本块、段落、工作表单元格、幻灯片及文件 hash。支持本地/SSH工作区及 AI 可见来源；nextOffset 非空时继续读取，不声称全文已读。仅返回已保存内容。',parameters:{type:'object',required:['path'],properties:{path:{type:'string'},source:{type:'string'},offset:{type:'integer',minimum:0}}},handler(){throw new Error('office_document_read 必须由 aide 原生工作区执行器调用');}});
    ctx.tool({name:'office_document_edit',description:'按最新 office_document_read 返回的 hash、文本块 id 和 expectedText 精确修改 DOCX/XLSX/PPTX。changes=[{id,expectedText,newText}]，最多100项，全部校验成功才保存。只读预览或空闲已保存的编辑器不阻止写入；活跃编辑/待保存时应稍后重试。替换段落沿用首个文本运行格式；复杂字段对象拒绝修改，原媒体保持。',parameters:{type:'object',required:['path','hash','changes'],properties:{path:{type:'string'},source:{type:'string'},hash:{type:'string'},changes:{type:'array',minItems:1,maxItems:100,items:{type:'object',required:['id','expectedText','newText'],properties:{id:{type:'string'},expectedText:{type:'string'},newText:{type:'string'}}}}}},handler(){throw new Error('office_document_edit 必须由 aide 原生工作区执行器调用');}});
    ctx.tool({
      name: 'office_create',
      description: '直接生成 DOCX/XLSX/PPTX 并优先写入当前工作空间绑定的自动系统文档目录（本地或工作空间 SFTP）；未绑定时写入工作区，不覆盖同名文件。docx content={title,blocks:[{type:"heading"|"paragraph",text,level?}|{type:"table",rows:[[...]]}]}；xlsx content={sheets:[{name,rows:[[...]]}]}；pptx content={slides:[{title,body}]}。',
      parameters: {
        type: 'object', required: ['path', 'format', 'content'],
        properties: {
          path: { type: 'string', description: '自动系统文档目录的相对路径；未绑定时相对工作区，后缀与格式一致' },
          format: { type: 'string', enum: ['docx', 'xlsx', 'pptx'] },
          content: {
            type: 'object', additionalProperties: false,
            description: '只填写当前 format 对应的字段：docx 用 title/blocks，xlsx 用 sheets，pptx 用 slides。不要用 paragraphs、data 或 content 替代正文键；生成后用 read_file 从来源 system-docs 读回核对。',
            properties: {
              title: {type:'string', description:'DOCX 主标题'},
              blocks: {type:'array', description:'DOCX 正文区块，例如 [{type:"paragraph",text:"正文"}]', items:{type:'object', properties:{type:{type:'string',enum:['heading','paragraph','table']},text:{type:'string'},level:{type:'integer',minimum:1,maximum:9},rows:{type:'array',items:{type:'array',items:{type:['string','number','boolean','null']}}}},additionalProperties:false}},
              sheets: {type:'array',minItems:1,description:'XLSX 工作表，例如 [{name:"数据",rows:[["名称","数量"],["样品",2]]}]',items:{type:'object',properties:{name:{type:'string'},rows:{type:'array',items:{type:'array',items:{type:['string','number','boolean','null']}}}},additionalProperties:false}},
              slides: {type:'array',minItems:1,description:'PPTX 幻灯片，例如 [{title:"标题",body:"正文"}]',items:{type:'object',properties:{title:{type:'string'},body:{type:'string'}},additionalProperties:false}}
            }
          },
        },
      },
      handler() {
        throw new Error('office_create 必须由 aide 原生工作区执行器调用');
      },
    });
    ctx.tool({
      name: 'office_comments',
      description: '读取 DOCX 内嵌批注及其精确锚定原文。处理修改要求时先调用此工具；anchorValid=false 时不可猜测位置。支持本地和 SSH 工作区。',
      parameters: {type:'object',required:['path'],properties:{path:{type:'string',description:'工作区相对 DOCX 路径'}}},
      handler() { throw new Error('office_comments 必须由 aide 原生工作区执行器调用'); },
    });
    ctx.tool({
      name: 'office_comment_edit',
      description: '按照一条 DOCX 内嵌批注修改其精确锚定的原文。先用 office_comments 看批注，理解指示并形成 newText；只有 expectedText 与当前锚点逐字一致时写入。保留批注供人工复核，不自动标记已解决。',
      parameters: {type:'object',required:['path','id','expectedText','newText'],properties:{path:{type:'string'},id:{type:'integer'},expectedText:{type:'string'},newText:{type:'string'}}},
      handler() { throw new Error('office_comment_edit 必须由 aide 原生工作区执行器调用'); },
    });
  },
};
