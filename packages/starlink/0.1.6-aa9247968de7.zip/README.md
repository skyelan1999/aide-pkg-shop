# StarLink · 星图查询

供 Aide AI 直接调用当前工作区星图分析结果的只读常驻插件。没有独立界面，安装启用后直接在对话中使用。

## 安装与使用

1. 在 Aide 插件市场安装 StarLink，或上传 Release 中的 `aide-pkg-StarLink-v0.1.6.zip`，启用插件。
2. 确认插件守护进程为运行状态；从旧版升级会启动常驻进程，首次安装若未自动启动，可在 Aide 插件管理的守护进程控制中启动 StarLink。
3. 对 Aide 说：“用 StarLink 汇总当前星图分析结果”“用 StarLink 搜索 workflow”“查看节点 C… 的入站关系”。

| AI 工具 | 用途 |
| --- | --- |
| `starlink_status` | 当前星图工作区、修订与完整性状态 |
| `starlink_summary` | 节点/关系计数、代码解析计数、连接热点 |
| `starlink_search` | 按关键词、类型、区域检索已收录节点 |
| `starlink_node` | 节点位置、索引摘要、入站/出站关系及证据 |
| `starlink_path` | 两节点最短证据路径，默认有向且排除目录包含关系 |

查询参数 `code` 可覆盖默认代码分析模式。搜索默认 20 条、最多 100 条；节点关系默认 30 条、最多 100 条。路径默认最大 8 跳、可设 1–24 跳；`undirected` 允许逆向追溯，`includeStructure` 包含目录关系。反向追溯不会改变证据的原始箭头。

## 兼容与权限

基础查询兼容 Aide `0.1.17.1 RC1`；新增标题与函数声明检索需要 Aide `0.1.17.2 RC1` 提供结构索引。不包含独立分析器，也不发起模型调用或向外部服务上传资料。

这是可信 Node.js 插件，默认在 Aide Docker 容器内执行。后端从 `/data/auth/access-token` 读取本机 Aide 令牌，以 `/data/certs/cert.pem` 校验 HTTPS，仅访问 `127.0.0.1:8080` 的固定只读接口。令牌保留在进程内，不传给模型或日志。**不要把令牌填到插件设置或聊天中。** 插件遵守调用前后工作区身份、策略代际和锁屏代际核对；五个工具通过 Aide 现有模型工具调用入口执行。

设置仅包含 `includeCode`、容器内部 `port`、运行数据 `dataDir`。宿主浏览器端口 9999 不是容器内部端口。非默认目录可调整 `dataDir`，证书校验保持开启，连接地址固定为回环，不能配置远程 Aide。

首版支持 Docker 标准 `/workspace`、`/context`、`/local` 映射及 `hostLocal` 下可确认的 POSIX 路径。SSH 工作区、`~/` 和 Windows 盘符路径会明确拒绝；不会回退到其他工作区。

## 快照检索性能

v0.1.2 复用 Aide 现有增量快照接口：常驻进程免去逐次启动 Node；每次仍核对工作区、策略和锁屏代际，并向宿主请求最新增量，没有通过延长有效期跳过新鲜度检查。节点定位、邻接关系和归一化检索字段按快照复用。

缓存只在内存中，最多两种代码模式，节点/关系序列化大小合计上限 96 MiB；实际进程内存还包含 JSON 对象、归一化文本和索引开销。作用域变化、锁定检查失败、请求失败或进程停止后不会复用旧基线。模型查询不因错误自动重放。

同一份真实快照、九组中英文/未命中查询，与 0.1.1 的真实 Aide 短命宿主对照，搜索热查询 P50 从 135.3 ms 降至 9.43 ms（14.3 倍）；其余数据查询 37.7–108.8 倍。结果逐项一致。首次进程启动和全量快照装载、宿主增量重扫、AI 思考及生成不在热查询加速承诺内。见 [性能报告](docs/PERFORMANCE.md)。

## 结果边界

- 查询复用星图现有索引，可能促使宿主同步当前扫描批次；不更改索引策略、不自动开启后台全库扫描。
- 状态检查仅确认接口和工作区身份，不加载全量快照，也不声称已知覆盖范围。其他查询最多读取 96 MiB 快照，超过限制明确报错，请缩小宿主索引范围。
- 每次返回 `workspace`、`revision`、`fetchedAt`、`stale`、`truncated`、`partial`、来源覆盖范围及 warnings。扫描尚未覆盖的材料不计为不存在。
- 文本是宿主已索引的摘要，不保证全文；详情最多 2000 字符，关系证据最多 600 字符。
- 调用关系和路径是静态分析证据，不能证明运行时调用、接口上线或测试通过。
- v0.1.1 起不再提供独立工作台。需要三维视图时，使用 Aide 文件面板的「知识星图」。
- 不保存文件、不执行命令、不修改资料。缺少窄范围资源声明时，由宿主保守调度整个插件执行域。

## 开发与打包

需要 Node.js 和 Python 3，无第三方安装依赖。

```sh
npm test
npm run build
```

生成可直接上传的 ZIP 和 SHA256 文件。`index.js` 自包含且小于 Aide 256 KiB 限制；包内只含工具入口、清单及说明，没有界面资源。

验证状态见 [docs/VERIFICATION.md](docs/VERIFICATION.md)。

### v0.1.3：标题与函数声明检索

配套 Aide 核心提供 `outline` 时，`starlink_search` 同时匹配标题与函数声明候选，返回命中项的 `match.kind/line/text`、短摘录和节点位置，不返回完整结构索引。节点详情仅给结构项数量与截断状态。建议AI使用 `limit=5` 至 `20` 控制候选数量；标题/声明检索可用 `code=false`，无需启用完整AST视图。已有摘要搜索保持兼容；未命中不代表全文不存在。

核心逐文件流式提取并限制结构大小，不缓存全文，不执行项目代码，不调用云端模型。函数匹配是词法声明候选，不生成调用关系。单文件最多扫描256 KiB、保存32项及4 KiB结构文本；单视图结构项估算预算8 MiB。预算不等同整个进程内存上限。对旧版宿主自动保留摘要检索。

同目录1199文件实测：原10题保持8/10命中，新增3道结构题从0/3变为2/3；共同命中题的热查询P50为30.37 ms，指定全文搜索流程为80.72 ms（约2.66倍）。这是固定快照与既定关键词的对照，未计AI思考、索引构建或全部真实HTTP开销，不是普遍加速承诺。详细方法和边界见[轻量索引实测](docs/reviews/2026-10-19-light-index.md)。

## 许可证

本项目采用 [MIT License](LICENSE)，版权声明见 LICENSE。0.1.4 起安装包包含 LICENSE 和声明 MIT 的 package.json。

## 0.1.6 compatibility

Version 0.1.6 uses Unicode 17.0 default full case folding and canonical normalization. Search excerpts retain original text. It requests `scope=ai` on both knowledge-map identity and updates and requires the host to acknowledge that scope. A host without the new API fails explicitly before downloading graph text. Hiding a reference invalidates the AI cache; manual browsing remains available.

See [current source verification](docs/reviews/2026-11-12-unicode-visibility.md). Requires Aide 0.1.19.0 RC1 or newer. Update the host before installing this package; old hosts fail explicitly. Previous releases remain available, and host updates do not replace an installed plugin.


### SSH 工作区（0.1.6）

SSH 调用读取当前宿主中与所选远端工作区身份一致的 AI 可见范围星图。插件不接收 SSH 密钥，不扫描本机 `/workspace`，也不创建自己的 SSH 连接。工作区身份、锁定代次、可见性策略或索引状态在查询期间变化时丢弃结果；旧宿主缺少 AI scope 确认时仍拒绝。主机代码索引本身的扫描范围与完整性限制继续适用。需要 Aide 0.1.19.0 RC1；通过市场或手动导入升级已安装插件。
