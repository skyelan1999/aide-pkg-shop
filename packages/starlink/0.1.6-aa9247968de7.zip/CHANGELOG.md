# Changelog

## 0.1.6 — 2026-11-12

- Use Unicode 17 default full case folding plus canonical normalization, preserving original excerpt positions (#804/#805 in Aide).
- Request and require explicit AI-scoped host graph snapshots; invalidate cached data after visibility changes (#796 in Aide). Requires the corresponding Aide host update.
- Includes authorized SSH workspace graph support from the merged 0.1.6 implementation; requires Aide 0.1.19.0 RC1. Host and installed plugin upgrades are separate.

## 0.1.4 — 2026-10-20

- 补充 MIT LICENSE，package.json 和插件清单明确声明 MIT。
- ZIP 随包分发许可证及包元数据，市场许可证登记更新为 MIT。
- 查询工具实现保持 0.1.3 版本。

## 0.1.3 — 2026-10-19

- 配合 Aide 0.1.17.2 RC1，检索有界标题和函数声明索引，返回命中片段及源行号。
- 不缓存全文，不生成调用关系；旧宿主继续使用摘要检索。
- 建议 AI 搜索 limit=5–20；保留覆盖范围、截断和过期标志。
- 17项插件回归通过；同目录结构题新增2项命中，详细比较方法随包提供。

## 0.1.2 — 2026-10-19

- 使用宿主支持的常驻插件进程和 HTTPS 连接复用。
- 按工作区/策略/锁屏代际隔离内存快照，使用增量游标同步变更、删除和服务端 reset。
- 复用归一化检索字段、节点和关系索引；只格式化最终返回的搜索项。
- 同快照对照：搜索热查询中位耗时提升 14.3 倍，所有结果与旧版一致；冷启动与全量装载单列。

## 0.1.1 — 2026-10-19

- 移除独立工作台与全部界面资源，直接在 Aide 对话中使用。
- 保留五个只读 AI 查询工具，工具实现与 v0.1.0 完全一致。
- 提供 Release 安装包和插件市场登记。

## 0.1.0 — 2026-10-19

- 新增五个可执行星图查询工具。
- 新增摘要、搜索、来源详情和证据路径快捷工作台。
- 返回索引完整性与来源范围；核对工作区和锁屏代际。
- 提供无外部依赖的 ZIP 打包和回归测试。


## 0.1.6 implementation details

- Query the matching host graph for SSH workspaces with no local-root fallback.
- Preserve explicit AI scope, lock/epoch/policy guards and Unicode/cache behavior.
- Unit tests and exact candidate ZIP/daemon acceptance against a real isolated SSH workspace passed; publication is separate.
