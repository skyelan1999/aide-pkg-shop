'use strict';
// Original photo bytes travel with .pp files; archive paths never travel.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const extensions={'image/jpeg':'.jpg','image/png':'.png','image/webp':'.webp','image/heic':'.heic','image/heif':'.heif','image/avif':'.avif','image/gif':'.gif'};
const digest=b=>crypto.createHash('sha256').update(b).digest('hex');
function refs(p){const out=new Map();function walk(x){if(!x||typeof x!=='object')return;if(x.mime&&x.sha256&&x.size){if(!extensions[x.mime]||! /^[a-f0-9]{64}$/.test(x.sha256)||!Number.isInteger(x.size)||x.size<1||x.size>64*1024*1024)throw Error('Invalid portable photo');out.set(x.sha256,x);}for(const v of Object.values(x))if(v&&typeof v==='object')walk(v);}walk(p);return out;}
function directory(p){try{fs.mkdirSync(p,{mode:0o700});}catch(e){if(e.code!=='EEXIST')throw e;}const s=fs.lstatSync(p);if(!s.isDirectory()||s.isSymbolicLink())throw Error('Unsafe photo archive directory');}
function folder(base,scope,create){if(typeof scope!=='string'||!scope)throw Error('Photo workspace scope unavailable');if(create)directory(base);base=fs.realpathSync(base);const result=path.join(base,'mobile','photos',digest(scope));if(create){directory(path.join(base,'mobile'));directory(path.join(base,'mobile','photos'));directory(result);}return result;}
function pack(base,scope,p,content){const envelope=JSON.parse(content),attachments={};let total=0;const root=folder(base,scope,false);for(const [sha,ref]of refs(p)){
 if(fs.realpathSync(root)!==root)throw Error('Unsafe photo archive');const file=path.join(root,sha+extensions[ref.mime]);let fd;
 try{fd=fs.openSync(file,fs.constants.O_RDONLY|fs.constants.O_NOFOLLOW);const s=fs.fstatSync(fd);if(!s.isFile()||s.size!==ref.size)throw Error('照片原件大小不一致');total+=s.size;if(total>7*1024*1024)throw Error('照片合计超过当前单文件传输限额；未保存，请保留原件并拆分项目');const raw=fs.readFileSync(fd);if(digest(raw)!==sha)throw Error('照片原件 SHA-256 不一致');attachments[sha]={mime:ref.mime,size:ref.size,base64:raw.toString('base64')};}
 catch(e){throw Error('无法完整打包 .pp 照片：'+e.message);}finally{if(fd!==undefined)fs.closeSync(fd);}
 }if(Object.keys(attachments).length)envelope.attachments=attachments;const packed=JSON.stringify(envelope);if(Buffer.byteLength(packed)>8*1024*1024)throw Error('.pp 超过当前 8 MiB 单文件限额，未保存');return packed;}
function restore(base,scope,p,content){const envelope=JSON.parse(content);if(!envelope.storage)return;const references=refs(p),assets=envelope.attachments||{};if(!assets||typeof assets!=='object'||Array.isArray(assets)||Object.keys(assets).some(k=>!references.has(k)))throw Error('Invalid PP photo manifest');
 // Validate every embedded original before writing any to the working archive.
 const checked=[];for(const [sha,asset]of Object.entries(assets)){const ref=references.get(sha);if(asset.mime!==ref.mime||asset.size!==ref.size||typeof asset.base64!=='string')throw Error('PP photo metadata mismatch');const raw=Buffer.from(asset.base64,'base64');if(raw.length!==ref.size||digest(raw)!==sha)throw Error('PP photo SHA-256 mismatch');checked.push({sha,ref,raw});}
 if(!checked.length)return;const root=folder(base,scope,true);for(const {sha,ref,raw}of checked){const target=path.join(root,sha+extensions[ref.mime]);if(fs.existsSync(target)){const fd=fs.openSync(target,fs.constants.O_RDONLY|fs.constants.O_NOFOLLOW);try{if(digest(fs.readFileSync(fd))!==sha)throw Error('Existing photo archive differs');}finally{fs.closeSync(fd);}continue;}const tmp=target+'.'+crypto.randomUUID()+'.tmp';try{fs.writeFileSync(tmp,raw,{flag:'wx',mode:0o600});fs.renameSync(tmp,target);}finally{if(fs.existsSync(tmp))fs.unlinkSync(tmp);}}
}
module.exports={pack,restore,refs};
