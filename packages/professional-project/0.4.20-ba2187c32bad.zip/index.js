'use strict';
const fs=require('node:fs'),path=require('node:path');
const text={type:'string',maxLength:2048},project={type:'object'},source={type:'string',maxLength:80};
const page={includeProject:{type:'boolean',description:'Return complete native project for editing; false by default'},offset:{type:'integer',minimum:0},limit:{type:'integer',minimum:1,maximum:1000}};
const input={project,path:text,fileSource:source,format:{type:'string',enum:['pp','json','xml','xlsx']},controlFilters:{type:'object',properties:{asOf:text,fromDate:text,toDate:text,personId:text},additionalProperties:false},...page};
const obj=properties=>({type:'object',properties,additionalProperties:false});
const quantity={type:'number',minimum:0.000001,maximum:1000000000},amount={type:'number',minimum:0,maximum:100000000};
const orderFields=obj({materialId:text,supplier:text,quantity,unitPrice:amount,dueDate:text,taskId:text});
const materialFields=obj({sku:text,name:text,unit:text,openingQuantity:{type:'number',minimum:0,maximum:1000000000},safetyStock:{type:'number',minimum:0,maximum:1000000000},barcodes:{type:'string',maxLength:1024}});
const movementFields=obj({materialId:text,quantity:{type:'number',minimum:-1000000000,maximum:1000000000},orderId:text,reservationId:text,taskId:text,areaId:text,shelfId:text,level:{type:'integer',minimum:1,maximum:30}});
const reservationFields=obj({materialId:text,quantity,taskId:text});
const tools=[
 ['history','Local recovery cache only; never overwrites project files. List/load snapshots, save a draft snapshot or toggle autosave. Scope is the current workspace',{action:{type:'string',enum:['preferences','list','snapshot','load']},project,documentKey:text,title:text,filename:text,fileSource:source,reason:text,id:text,enabled:{type:'boolean'},metricsCollapsed:{type:'boolean'},taskFilter:text,taskScale:text,organizationZoom:{type:'number',minimum:0.2,maximum:2}},['action']],
 ['status','Local engine status and configured file sources; action=browse lists one source directory read-only, with project-format filtering and bounded pages',{action:{type:'string',enum:['status','browse','saveTarget','captureService','stockQuery']},capture:{type:'object'},projectId:text,revision:text,scope:obj({buildingId:text,floorId:text,warehouseId:text,areaId:text,shelfId:text,level:text}),fileSource:source,path:text,query:{type:'string',maxLength:120},fileType:{type:'string',enum:['project','all']},offset:{type:'integer',minimum:0,maximum:5000},limit:{type:'integer',minimum:1,maximum:500}},[]],
 ['create','Create a local in-memory project with optional demo. Does not save files',{name:text,startDate:text,template:{type:'string',enum:['blank','demo']},...page},[]],
 ['open','Read and calculate a project from a configured Aide workspace/reference; return bounded task rows',{path:text,fileSource:source,...page},['path']],
 ['import','Parse uploaded file bytes locally. XML is an MSPDI subset; XLSX requires project table headers',{contentBase64:{type:'string',maxLength:12000000},format:input.format,...page},['contentBase64','format']],
 ['calculate','Recalculate working-minute CPM, summary tasks, milestones, resource overloads and costs; no writes',input,[]],
 ['validate','Validate hierarchy, dependencies, calendars and resource references; no writes',input,[]],
 ['update','Apply task/resource changes (taskOrder reorders IDs; task scheduleMode auto/unscheduled; status active/closed with closedReason) OR management controls (budget, expense, demand, availability, risk, change). All management mutations require reason. controlFilters selects report dates/person. Optional savePath proposes a reviewed .pp write; no direct source writes',{...input,changes:{type:'object'},reason:text,management:obj({domain:{type:'string',enum:['budget','expense','demand','availability','risk','change','keyRecord']},action:{type:'string',enum:['upsert','add','delete','status']},record:obj({id:text,name:text,title:text,description:text,taskId:text,personId:text,ownerId:text,materialId:text,category:{type:'string',enum:['labor','material','other']},amount:{type:'number',minimum:0,maximum:1000000000000},quantity,needDate:text,date:text,reference:text,start:text,end:text,kind:{type:'string',enum:['leave','unavailable']},dueDate:text,probability:{type:'integer',minimum:1,maximum:5},impact:{type:'integer',minimum:1,maximum:5},mitigation:text,costImpact:{type:'number',minimum:-1000000000000,maximum:1000000000000},durationImpactMinutes:{type:'integer',minimum:-1000000,maximum:1000000}}),id:text,status:text,reason:text}),savePath:text},[]],
 ['procurement','Create or transition local purchase orders; reason required. No supplier contact or payments',{...input,action:{type:'string',enum:['create','order','cancel','close']},order:orderFields,id:text,reason:text,savePath:text},['action','reason']],
 ['inventory','Add materials or journal receipt/issue/adjustment. Order receipts and reserved issues are validated',{...input,action:{type:'string',enum:['material','receipt','issue','adjustment','barcodes','mobile','building','floor','deleteLocation','warehouse','feature','area','shelf','object','mobileStage','archiveReceipt','archiveReceipts','voidReceipt']},id:text,barcodes:{type:'string',maxLength:1024},batch:{type:'object'},receipts:{type:'array',items:{type:'object'},maxItems:200},personId:text,location:{type:'object'},areaId:text,shelfId:text,level:{type:'integer',minimum:1,maximum:30},materialId:text,orderId:text,material:materialFields,movement:movementFields,reason:text,savePath:text},['action','reason']],
 ['freeze','Freeze/unfreeze project plan or reserve/release stock; explicit reason required. Local consistency, not access control',{...input,action:{type:'string',enum:['plan','unfreezePlan','reserve','release']},reservation:reservationFields,id:text,reason:text,savePath:text},['action','reason']],
 ['organization','Arrange department hierarchy, leaders, people, reporting lines and unique project resource links; no external directory changes',{...input,action:{type:'string',enum:['department','person','deleteDepartment','deletePerson','reorderDepartments']},department:obj({id:text,name:text,parentId:text,leaderId:text}),person:obj({id:text,name:text,role:text,personNumber:text,phone:text,email:text,wechat:text,address:text,notes:text,departmentId:text,managerId:text,resourceId:text,overtimeHourlyRate:{type:'number',minimum:0,maximum:1000000},workingDayMultiplier:{type:'number',minimum:0,maximum:10},restDayMultiplier:{type:'number',minimum:0,maximum:10},holidayMultiplier:{type:'number',minimum:0,maximum:10}}),id:text,ids:{type:'array',items:text,maxItems:200},reason:text,savePath:text},['action','reason']],
 ['overtime','Record/confirm/void overtime, use/void compensatory time or report recorded minutes. Civil dates, manual categories/credits, custom rate estimates only, no payroll settlement or legal inference',{...input,action:{type:'string',enum:['add','confirm','void','timeoff','voidTimeoff','report']},record:obj({personId:text,taskId:text,start:text,end:text,breakMinutes:{type:'integer',minimum:0,maximum:1439},category:{type:'string',enum:['workingDay','restDay','holiday']},compMinutes:{type:'integer',minimum:0,maximum:4320},hourlyRate:{type:'number',minimum:0,maximum:1000000},multiplier:{type:'number',minimum:0,maximum:10}}),timeoff:obj({personId:text,date:text,minutes:{type:'integer',minimum:1,maximum:1440}}),filters:obj({fromDate:text,toDate:text,personId:text,departmentId:text,taskId:text,category:text,status:text}),id:text,reason:text,savePath:text},['action']],
 ['baseline','Capture a baseline in the returned project. Saving still requires an explicit save/export',{...input,name:text},[]],
 ['save','Validate a project and propose a .pp workspace write. Host approval applies; no direct disk writes',{project,path:text},['project','path']],
 ['export','Convert a project or source file to pp/json/MS Project XML subset/XLSX; return bounded base64, prefer UI export',{...input,outputFormat:{type:'string',enum:['pp','json','xml','xlsx','pdf']}},['outputFormat']]
];
async function prepare(a,api){
 const clean={...a};delete clean.fileSource;delete clean.path;delete clean.savePath;
 if(a.path&&a.project)throw Error('Provide a project or a path, not both');
 if(!a.path)return clean;
 if(!api.sources)throw Error('Update Aide for configured project file sources');
 const staged=await api.sources({operation:'stage',source:a.fileSource||'workspace',path:a.path,slot:'path',maxBytes:8388608});
 const base=path.resolve(staged.workspace),file=path.resolve(base,staged.path);
 if(file===base||!file.startsWith(base+path.sep))throw Error('Invalid source snapshot');
 const stat=fs.lstatSync(file);if(!stat.isFile()||stat.isSymbolicLink()||stat.size>8388608)throw Error('Project file exceeds limits');
 return {...clean,format:a.format||path.extname(a.path).slice(1).toLowerCase(),contentBase64:fs.readFileSync(file).toString('base64')};
}
async function engine(operation,args,api){const input={operation,arguments:args},raw=await require('./offline-adapter.cjs').worker(input);const data=typeof raw==='string'?JSON.parse(raw):raw;if(!data.ok)throw Error(data.error||'Project engine failed');const result=data.result,base=path.join(__dirname,'..','.professional-project-state');
 if(result.project){const scope=await inventoryScope(api);if(args.format==='pp'&&args.contentBase64)require('./portable-assets.js').restore(base,scope,result.project,Buffer.from(args.contentBase64,'base64').toString('utf8'));result.inventoryIndex=require('./inventory-db.js').sync(base,scope,result.project);}
 if(operation==='save'||operation==='export'&&args.outputFormat==='pp'){const content=operation==='save'?result.content:Buffer.from(result.contentBase64,'base64').toString('utf8'),packed=require('./portable-assets.js').pack(base,await inventoryScope(api),args.project,content);if(operation==='save')result.content=packed;else{result.contentBase64=Buffer.from(packed).toString('base64');result.bytes=Buffer.byteLength(packed);}}
 return result;}
async function inventoryScope(api){if(api.sources){const info=await api.sources({operation:'sources'});const w=info.sources?.find(x=>x.id==='workspace');if(w?.workspaceKey)return w.workspaceKey;if(w?.origin)return w.origin;}if(api.workspaceRoot)return api.workspaceRoot;throw Error('Inventory workspace scope unavailable');}
function savePath(value){if(typeof value!=='string'||value.length>2048||!value.toLowerCase().endsWith('.pp')||value.startsWith('/')||/[\\\x00-\x1f]/.test(value)||value.split('/').some(x=>!x||x==='.'||x==='..'))throw Error('Use a relative workspace .pp path');return value;}
module.exports={name:'professional-project',apply(ctx){for(const [op,description,properties,required]of tools)ctx.tool({name:'pp_'+op,description,parameters:{type:'object',properties,required,additionalProperties:false},handler:async(a={},api)=>{
 if(!api||!a||typeof a!=='object'||Array.isArray(a)||Object.keys(a).some(k=>!Object.hasOwn(properties,k)))throw Error('Invalid project arguments');if(required.some(key=>a[key]===undefined))throw Error('Missing required project argument');
 if(op==='history'){
  let scope=api.workspaceRoot;
  if(api.sources){const info=await api.sources({operation:'sources'});const workspace=info.sources?.find(x=>x.id==='workspace');if(!workspace)throw Error('Workspace history scope is unavailable');scope=workspace.workspaceKey||(api.workspaceRoot?'local:'+path.resolve(api.workspaceRoot):workspace.origin);}
  if(typeof scope!=='string'||!scope)throw Error('Workspace history scope is unavailable');
  const args={...a};if(a.action==='snapshot')args.project=(await engine('validate',{project:a.project,includeProject:true,limit:1},api)).project;
  const cached=require('./history.js').store(path.join(__dirname,'..','.professional-project-state'),scope,args);
  if(a.action==='load')return {...await engine('calculate',{project:cached.project,includeProject:true,limit:1000},api),historyEntry:cached.entry};
  return cached;
 }
 if(op==='status'){
  if(a.action==='stockQuery'){if(Object.keys(a).some(k=>!['action','projectId','revision','scope','query','offset','limit'].includes(k)))throw Error('Invalid stock query arguments');return require('./inventory-db.js').query(path.join(__dirname,'..','.professional-project-state'),await inventoryScope(api),a);}
  if(a.action==='captureService'){if(Object.keys(a).some(k=>!['action','capture'].includes(k)))throw Error('Invalid service arguments');return require('./offline-adapter.cjs').mobile(a.capture||{},api);}
  if(a.action==='saveTarget'){
   const target=savePath(a.path);if(Object.keys(a).some(k=>!['action','path'].includes(k)))throw Error('Save target inspection only accepts a workspace path');
   if(!api.sources)throw Error('Update Aide to inspect the workspace save target');
   const parts=target.split('/');if(parts.length>33)throw Error('Save target exceeds 32 directory levels');let parent='.';
   for(let i=0;i<parts.length;i++){
    const listed=await api.sources({operation:'browse',source:'workspace',path:parent});if(!Array.isArray(listed.entries)||listed.entries.length>5000||listed.truncated)throw Error('Cannot confirm save target from an incomplete directory listing');
    const current=parent==='.'?parts[i]:parent+'/'+parts[i],entry=listed.entries.find(e=>e.path===current);
    if(!entry)return {path:target,exists:false,attachments:[]};
    if(i===parts.length-1){if(entry.kind!=='file')throw Error('Save target is not a regular file');return {path:target,exists:true,attachments:[{root:'workspace',path:target}]};}
    if(entry.kind!=='directory')throw Error('Save target parent is not a regular directory');parent=current;
   }
  }
  if(a.action==='browse'){
   if(!api.sources)throw Error('Update Aide to browse workspace and reference directories');
   const dir=a.path===undefined?'.':a.path,selector=a.fileSource||'workspace',offset=a.offset??0,limit=a.limit??200,query=a.query??'';
   if(typeof dir!=='string'||!dir||dir.length>2048||dir.startsWith('/')||/[\\\x00-\x1f]/.test(dir)||dir!=='.'&&dir.split('/').some(x=>!x||x==='.'||x==='..'))throw Error('Use a relative source directory path');
   if(typeof selector!=='string'||selector.length>80||!Number.isInteger(offset)||offset<0||offset>5000||!Number.isInteger(limit)||limit<1||limit>500||typeof query!=='string'||query.length>120||a.fileType!==undefined&&!['project','all'].includes(a.fileType))throw Error('Invalid directory browse options');
   const listed=await api.sources({operation:'browse',source:selector,path:dir});
   if(!Array.isArray(listed.entries)||listed.entries.length>5000)throw Error('Directory listing exceeds 5000 entries; use a narrower path');
   const matches=listed.entries.filter(e=>typeof e.path==='string'&&['directory','file'].includes(e.kind)&&(e.kind==='directory'||(a.fileType==='all'||/\.(pp|xml|json|xlsx)$/i.test(e.path))&&path.posix.basename(e.path).toLocaleLowerCase().includes(query.toLocaleLowerCase()))).sort((a,b)=>(a.kind==='directory'?0:1)-(b.kind==='directory'?0:1)||a.path.localeCompare(b.path,'zh-CN',{numeric:true}));
   return {path:dir,source:listed.source,entries:matches.slice(offset,offset+limit),total:matches.length,offset,limit,hasMore:offset+limit<matches.length,truncated:!!listed.truncated};
  }
  if(a.action!==undefined&&a.action!=='status'||Object.keys(a).some(k=>k!=='action'))throw Error('Browse arguments require action=browse');
  return {...await engine(op,{},api),packageVersion:require('./manifest.json').version,...(api.sources?await api.sources({operation:'sources'}):{sources:[]})};
 }
 if(op==='save'){const result=await engine('save',{project:a.project},api);return {...api.proposeWrite(savePath(a.path),result.content),summary:result.summary,warnings:result.warnings};}
 const prepared=await prepare(a,api);
 if(op==='inventory'&&['receipt','issue','adjustment','mobile','mobileStage','archiveReceipt','archiveReceipts','voidReceipt'].includes(a.action)&&!a.personId)throw Error('请选择组织架构中的登记员工');
 if(a.savePath)prepared.includeProject=true;
 if(op==='export'&&!prepared.project){const loaded=await engine('import',{...prepared,includeProject:true,limit:1},api);prepared.project=loaded.project;delete prepared.contentBase64;delete prepared.format;}
 const result=await engine(op,prepared,api);
 if(['update','procurement','inventory','freeze','organization','overtime'].includes(op)&&a.savePath){const saved=await engine('save',{project:result.project},api);return {...api.proposeWrite(savePath(a.savePath),saved.content),summary:saved.summary,warnings:saved.warnings};}
 return result;
}});}};

const __businessApply=module.exports.apply;module.exports.apply=function(ctx){let licensing;require('./offline-adapter.cjs').register({settings:ctx.settings,tool(t){licensing=t}},'professional-project','pp_license');return __businessApply({...ctx,tool(t){if(t.name==='pp_status'){const original=t.handler;t.parameters.properties.action.enum.push('license');t.parameters.properties.license=licensing.parameters;t.handler=async(a,api)=>{if(a.action==='license'){if(Object.keys(a).some(k=>!['action','license'].includes(k)))throw Error('授权参数无效');return licensing.handler(a.license||{},api);}return original(a,api);};}ctx.tool(t);}});};
