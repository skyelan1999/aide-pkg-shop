'use strict';
// Indexed, rebuildable working copy. Portable exports contain the same SQLite
// schema and the complete project document inside one .pp envelope.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {DatabaseSync}=require('node:sqlite');
const hash=s=>crypto.createHash('sha256').update(s).digest('hex');
function directory(p){try{fs.mkdirSync(p,{mode:0o700});}catch(e){if(e.code!=='EEXIST')throw e;}const st=fs.lstatSync(p);if(!st.isDirectory()||st.isSymbolicLink())throw Error('Unsafe inventory directory');}
function open(base,scope,id,create=false){
 if(typeof scope!=='string'||!scope||typeof id!=='string'||!id||id.length>128)throw Error('Inventory workspace and project scope required');
 directory(base);const dir=path.join(base,'inventory-sqlite');directory(dir);const file=path.join(dir,hash(scope+'\0'+id)+'.sqlite');
 if(fs.existsSync(file)){const st=fs.lstatSync(file);if(st.isSymbolicLink()||!st.isFile()||st.size>128*1024*1024)throw Error('Unsafe inventory database');}
 else if(!create)throw Error('库存索引尚未建立，请重新打开项目');
 const db=new DatabaseSync(file);fs.chmodSync(file,0o600);db.exec('PRAGMA busy_timeout=3000; PRAGMA trusted_schema=OFF;');return db;
}
function sync(base,scope,p){
 const raw=JSON.stringify(p),revision=hash(raw),db=open(base,scope,p.projectId,true);
 try{
  db.exec(fs.readFileSync(path.join(__dirname,'storage-schema.sql'),'utf8'));
  if(db.prepare('SELECT revision FROM document WHERE id=1').get()?.revision===revision)return {available:true,revision,storage:'sqlite'};
  db.exec('BEGIN IMMEDIATE');
  try{
   db.exec('DELETE FROM materials;DELETE FROM balances;');
   const used=new Map();for(const m of p.stockMovements||[])if(m.reservationId)used.set(m.reservationId,(used.get(m.reservationId)||0)+m.quantity);
   const frozen=new Map();for(const r of p.stockReservations||[])if(r.status==='active')frozen.set(r.materialId,(frozen.get(r.materialId)||0)+Math.max(0,r.quantity-(used.get(r.id)||0)));
   const material=db.prepare('INSERT INTO materials VALUES(?,?,?,?,?,?,?)'),balance=db.prepare('INSERT INTO balances VALUES(?,?,?,?,?,?,?,?)');
   for(const m of p.materials||[]){material.run(m.id,m.name,m.sku||'',m.unit||'',m.barcodes||'',m.safetyStock||0,frozen.get(m.id)||0);if(m.openingQuantity)balance.run(m.id,'','','','','','',m.openingQuantity);}
   const areas=new Map((p.stockAreas||[]).map(x=>[x.id,x])),spaces=new Map((p.warehouses||[]).map(x=>[x.id,x])),floors=new Map((p.floors||[]).map(x=>[x.id,x]));
   for(const m of p.stockMovements||[]){const a=areas.get(m.areaId),w=spaces.get(a?.warehouseId),f=floors.get(w?.floorId);balance.run(m.materialId,f?.buildingId||'',f?.id||'',w?.id||'',m.areaId||'',m.shelfId||'',String(m.level??''),m.type==='issue'?-m.quantity:m.quantity);}
   db.prepare('INSERT OR REPLACE INTO document VALUES(1,?,?)').run(revision,raw);db.exec('COMMIT');
  }catch(e){db.exec('ROLLBACK');throw e;}
  return {available:true,revision,storage:'sqlite'};
 }finally{db.close();}
}
function query(base,scope,a){
 const filters=a.scope||{},columns={buildingId:'building_id',floorId:'floor_id',warehouseId:'warehouse_id',areaId:'area_id',shelfId:'shelf_id',level:'level'};
 if(!filters||typeof filters!=='object'||Array.isArray(filters)||Object.keys(filters).some(k=>!Object.hasOwn(columns,k))||Object.values(filters).some(v=>typeof v!=='string'||v.length>128))throw Error('Invalid inventory location filters');
 const offset=a.offset??0,limit=a.limit??100,q=a.query??'';if(!Number.isInteger(offset)||offset<0||offset>10000000||!Number.isInteger(limit)||limit<1||limit>200||typeof q!=='string'||q.length>120)throw Error('Invalid inventory page');
 if(typeof a.revision!=='string'||!/^[a-f0-9]{64}$/.test(a.revision))throw Error('Inventory revision required');
 const db=open(base,scope,a.projectId);
 try{
  if(db.prepare('SELECT revision FROM document WHERE id=1').get()?.revision!==a.revision)throw Error('库存索引版本已变更，请重新计算或打开项目');
  const where=[],args=[];for(const [key,value]of Object.entries(filters)){if(!value)continue;if(key==='buildingId'&&value==='__unassigned')where.push("area_id=''");else{where.push(columns[key]+'=?');args.push(value);}}
  const filtered=where.length>0,search=q?" AND instr(lower(m.id||' '||m.name||' '||m.sku||' '||m.barcodes),lower(?))>0":'',baseSQL='WITH stock AS (SELECT material_id,ROUND(SUM(quantity),6) AS qty FROM balances'+(filtered?' WHERE '+where.join(' AND '):'')+' GROUP BY material_id) SELECT m.*,COALESCE(s.qty,0) AS onHand FROM materials m LEFT JOIN stock s ON s.material_id=m.id WHERE 1=1'+(filtered?' AND COALESCE(s.qty,0)<>0':'')+search;
  const params=[...args,...(q?[q]:[])],total=db.prepare('SELECT COUNT(*) AS n FROM ('+baseSQL+')').get(...params).n;
  const rows=db.prepare(baseSQL+' ORDER BY m.rowid LIMIT ? OFFSET ?').all(...params,limit,offset).map(m=>({id:m.id,name:m.name,sku:m.sku,unit:m.unit,barcodes:m.barcodes,safetyStock:m.safety,frozen:m.frozen,onHand:m.onHand,available:filtered&&m.frozen?null:Math.round((m.onHand-(filtered?0:m.frozen))*1e6)/1e6}));
  return {rows,total,offset,limit,hasMore:offset+rows.length<total,revision:a.revision,storage:'sqlite',filtered};
 }finally{db.close();}
}
module.exports={sync,query};
