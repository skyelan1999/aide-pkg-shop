'use strict';
// Recovery cache only. Never writes a user-selected source/project file.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const MAX_BYTES=100*1024*1024,WORKSPACE_BYTES=32*1024*1024,MAX_WORKSPACES=32;
function directory(p){try{fs.mkdirSync(p,{mode:0o700});}catch(e){if(e.code!=='EEXIST')throw e;}const st=fs.lstatSync(p);if(!st.isDirectory()||st.isSymbolicLink())throw Error('Unsafe history directory');}
function read(file,max=9*1024*1024){const fd=fs.openSync(file,fs.constants.O_RDONLY|fs.constants.O_NOFOLLOW);try{const st=fs.fstatSync(fd);if(!st.isFile()||st.size>max)throw Error('Invalid history entry');return JSON.parse(fs.readFileSync(fd,'utf8'));}finally{fs.closeSync(fd);}}
function atomic(file,value){const tmp=file+'.'+crypto.randomUUID()+'.tmp';try{fs.writeFileSync(tmp,JSON.stringify(value),{flag:'wx',mode:0o600});fs.renameSync(tmp,file);}finally{try{fs.unlinkSync(tmp);}catch(e){if(e.code!=='ENOENT')throw e;}}}
const hash=s=>crypto.createHash('sha256').update(s).digest('hex');
const publicEntry=e=>({id:e.id,documentKey:e.documentKey,title:e.title,filename:e.filename,fileSource:e.fileSource,createdAt:e.createdAt,reason:e.reason,bytes:e.bytes,digest:e.digest});
function store(base,scope,a){
 directory(base);let lock;
 const lockfile=path.join(base,'.lock');try{lock=fs.openSync(lockfile,'wx',0o600);}catch(e){if(e.code==='EEXIST'){const st=fs.lstatSync(lockfile);if(!st.isSymbolicLink()&&Date.now()-st.mtimeMs>120000){fs.unlinkSync(lockfile);lock=fs.openSync(lockfile,'wx',0o600);}else throw Error('历史存储忙，请稍后重试');}else throw e;}
 try{
  const root=path.join(base,hash(scope));directory(root);const prefs=path.join(root,'preferences.json');
  const entries=()=>fs.readdirSync(root).filter(n=>/^[a-f0-9-]{36}\.json$/.test(n)).map(n=>read(path.join(root,n))).sort((a,b)=>b.createdAt.localeCompare(a.createdAt)||b.id.localeCompare(a.id));
  const settings=()=>fs.existsSync(prefs)?read(prefs,4096):{autosave:false};
  if(a.action==='preferences'&&a.documentKey){
   if(typeof a.documentKey!=='string'||a.documentKey.length>200)throw Error('Invalid project preference key');
   const file=path.join(root,'view-'+hash(a.documentKey)+'.json');
   const current=fs.existsSync(file)?read(file,4096):{};
   const taskFilter=['all','critical','incomplete','active','closed','unscheduled'].includes(a.taskFilter)?a.taskFilter:['all','critical','incomplete','active','closed','unscheduled'].includes(current.taskFilter)?current.taskFilter:'all';
   const taskScale=['day','week','month','year'].includes(a.taskScale)?a.taskScale:['day','week','month','year'].includes(current.taskScale)?current.taskScale:'day';
   if(a.organizationZoom!==undefined&&(typeof a.organizationZoom!=='number'||!Number.isFinite(a.organizationZoom)||a.organizationZoom<.2||a.organizationZoom>2))throw Error('Invalid organization zoom');
   const organizationZoom=a.organizationZoom??(Number.isFinite(current.organizationZoom)&&current.organizationZoom>=.2&&current.organizationZoom<=2?current.organizationZoom:1);
   if(a.taskFilter!==undefined||a.taskScale!==undefined||a.organizationZoom!==undefined)atomic(file,{taskFilter,taskScale,organizationZoom});
   return {taskFilter,taskScale,organizationZoom};
  }
  if(a.action==='preferences'){const current=settings();if(a.enabled!==undefined&&typeof a.enabled!=='boolean')throw Error('Invalid autosave preference');if(a.metricsCollapsed!==undefined&&typeof a.metricsCollapsed!=='boolean')throw Error('Invalid overview preference');if(a.enabled!==undefined||a.metricsCollapsed!==undefined)atomic(prefs,{autosave:a.enabled??current.autosave,metricsCollapsed:a.metricsCollapsed??current.metricsCollapsed??false});return {...settings(),intervalSeconds:10,retention:{perDocument:20,perWorkspace:50,workspaceBytes:WORKSPACE_BYTES,totalBytes:MAX_BYTES}};}
  if(a.action==='list')return {entries:entries().map(publicEntry),...settings()};
  if(a.action==='load'){
   if(typeof a.id!=='string'||!/^[a-f0-9-]{36}$/.test(a.id))throw Error('Invalid history ID');
   const e=read(path.join(root,a.id+'.json'));if(e.id!==a.id||hash(JSON.stringify(e.project))!==e.digest)throw Error('History snapshot checksum mismatch');return {project:e.project,entry:publicEntry(e)};
  }
  if(a.action!=='snapshot')throw Error('Unknown history action');
  if(!a.project||typeof a.documentKey!=='string'||!a.documentKey||a.documentKey.length>2048)throw Error('Project and document key required');
  for(const key of ['title','filename','reason'])if(typeof a[key]!=='string'||a[key].length>2048)throw Error('Invalid history '+key);
  const raw=JSON.stringify(a.project),bytes=Buffer.byteLength(raw);if(bytes>8*1024*1024)throw Error('Draft exceeds 8 MiB history limit');
  const old=entries(),digest=hash(raw),documentKey=hash(a.documentKey),previous=old.find(e=>e.documentKey===documentKey);
  if(previous?.digest===digest)return {entry:publicEntry(previous),unchanged:true};
  const entry={id:crypto.randomUUID(),documentKey,title:a.title,filename:a.filename,fileSource:typeof a.fileSource==='string'?a.fileSource.slice(0,80):'workspace',createdAt:new Date(Math.max(Date.now(),old.length?Date.parse(old[0].createdAt)+1:0)).toISOString(),reason:a.reason,bytes,digest,project:a.project};atomic(path.join(root,entry.id+'.json'),entry);
  // Prune oldest recoverable snapshots within documented hard budgets.
  let count=0,total=0;const docs=new Map();for(const e of entries()){const diskBytes=fs.lstatSync(path.join(root,e.id+'.json')).size;const n=(docs.get(e.documentKey)||0)+1;docs.set(e.documentKey,n);if(n>20||count>=50||total+diskBytes>WORKSPACE_BYTES){fs.unlinkSync(path.join(root,e.id+'.json'));continue;}count++;total+=diskBytes;}
  let global=[];const roots=fs.readdirSync(base).filter(n=>/^[a-f0-9]{64}$/.test(n));
  for(const name of roots){const dir=path.join(base,name);if(fs.lstatSync(dir).isSymbolicLink())throw Error('Unsafe history scope');for(const file of fs.readdirSync(dir).filter(n=>/^[a-f0-9-]{36}\.json$/.test(n))){const st=fs.lstatSync(path.join(dir,file));if(!st.isFile()||st.isSymbolicLink())throw Error('Unsafe history entry');global.push({file:path.join(dir,file),bytes:st.size,time:st.mtimeMs,scope:name});}}
  global.sort((a,b)=>b.time-a.time);let used=0;const scopes=new Set();for(const e of global){if(used+e.bytes>MAX_BYTES||!scopes.has(e.scope)&&scopes.size>=MAX_WORKSPACES){fs.unlinkSync(e.file);continue;}used+=e.bytes;scopes.add(e.scope);}
  return {entry:publicEntry(entry),unchanged:false};
 }finally{fs.closeSync(lock);fs.unlinkSync(lockfile);}
}
module.exports={store};
