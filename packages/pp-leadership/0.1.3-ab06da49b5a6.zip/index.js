'use strict';

const fs = require('node:fs'),
  path = require('node:path'),
  Core = require('./offline-adapter.cjs').core;
function relative(p) {
  if (typeof p !== 'string' || !p || p.length > 2048 || p.startsWith('/') || /[\\\x00-\x1f]/.test(p) || p !== '.' && p.split('/').some(x => !x || x === '.' || x === '..')) throw Error('请使用来源内相对路径');
  return p;
}
module.exports = {
  name: 'pp-leadership',
  apply(ctx) {
    const tool = (name, description, properties, required, handler) => ctx.tool({
      name,
      description,
      parameters: {
        type: 'object',
        properties,
        required,
        additionalProperties: false
      },
      handler
    });
    tool('ppl_guide', 'PPLeaderShip 使用指南与分析边界。首次使用先读取。', {}, [], () => ({
      version: '0.1.1',
      formats: ['ProfessionalProject .pp schema 1', 'ProfessionalProject .pp schema 2 SQLite', 'PPLeaderShip .ppl'],
      readOnly: true,
      steps: ['ppl_sources 列出工作区/引用', 'ppl_inspect 分别读取各 .pp，保留 source 与 digest', 'ppl_analyze 对读取摘要和显式管理假设做组合分析'],
      limits: {
        projects: 50,
        sourceFileBytes: 8388608,
        localUploadBytes: 131072
      },
      boundaries: ['不改写 .pp；管理批注与决策保存在 .ppl', '不同币种分别汇总，不自动换汇', '战略评分为管理层输入，缺项不排名', '跨项目人员必须显式映射到公司人员编号，不按姓名或项目内 ID 自动合并', '摘要是读取时的快照；基准日变化需重新读取 .pp', '组合分析无模型请求；AI 深度分析由用户在 Aide 会话发起']
    }));
    tool('ppl_sources', '列出或浏览已授权的工作区/引用，仅展示目录与 .pp 文件。', {
      fileSource: {
        type: 'string'
      },
      path: {
        type: 'string'
      },
      offset: {
        type: 'integer',
        minimum: 0,
        maximum: 5000
      }
    }, [], async (a, api) => {
      if (!api.sources) throw Error('当前宿主不支持来源读取，请更新 Aide');
      if (!a.fileSource) return api.sources({
        operation: 'sources'
      });
      const r = await api.sources({
        operation: 'browse',
        source: a.fileSource,
        path: relative(a.path || '.')
      });
      if (!Array.isArray(r.entries) || r.truncated) throw Error('目录列表不完整，请选择更小目录');
      const entries = r.entries.filter(e => e.kind === 'directory' || e.kind === 'file' && /\.pp$/i.test(e.path)).sort((a, b) => (a.kind === 'directory' ? 0 : 1) - (b.kind === 'directory' ? 0 : 1) || a.path.localeCompare(b.path));
      const offset = a.offset || 0;
      return {
        entries: entries.slice(offset, offset + 200),
        hasMore: offset + 200 < entries.length,
        total: entries.length
      };
    });
    tool('ppl_inspect', '只读解析一个 .pp（JSON 或 SQLite 封装），返回带来源和 SHA256 的公司管理摘要。不写入项目、不恢复照片、不读取联系人隐私字段。', {
      fileSource: {
        type: 'string'
      },
      path: {
        type: 'string'
      },
      name: {
        type: 'string'
      },
      contentBase64: {
        type: 'string',
        maxLength: 174764
      },
      asOf: {
        type: 'string'
      }
    }, ['asOf'], async (a, api) => {
      let data, source;
      if (a.path) {
        if (a.contentBase64) throw Error('文件路径与上传内容不能同时提供');
        if (!/\.pp$/i.test(relative(a.path))) throw Error('请选择 .pp 文件');
        if (!api.sources) throw Error('需要新版 Aide 文件来源能力');
        const staged = await api.sources({
          operation: 'stage',
          source: a.fileSource || 'workspace',
          path: a.path,
          slot: 'path',
          maxBytes: 8388608
        });
        const base = fs.realpathSync(staged.workspace),
          file = fs.realpathSync(path.resolve(base, staged.path));
        if (!file.startsWith(base + path.sep)) throw Error('文件快照路径越界');
        const stat = fs.lstatSync(file);
        if (!stat.isFile() || stat.size > 8388608) throw Error('不支持的文件容量');
        data = fs.readFileSync(file);
        source = {
          kind: 'source',
          source: a.fileSource || 'workspace',
          path: a.path
        };
      } else {
        if (typeof a.contentBase64 !== 'string' || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(a.contentBase64)) throw Error('上传内容无效');
        data = Buffer.from(a.contentBase64, 'base64');
        if (data.length > 131072) throw Error('本机直传上限 128 KiB；请将文件放入工作区/引用后打开，支持 8 MiB');
        source = {
          kind: 'upload',
          name: String(a.name || 'uploaded.pp').slice(0, 200)
        };
      }
      const raw = await require('./offline-adapter.cjs').worker({
        contentBase64: data.toString('base64'),
        asOf: a.asOf
      });
      const out = typeof raw === 'string' ? JSON.parse(raw) : raw;
      if (!out.ok) throw Error(out.error || '无法解析 .pp');
      return {
        ...out.result,
        source
      };
    });
    tool('ppl_analyze', '分析已读取的多项目摘要与显式战略输入，返回币种分组预算、健康度和组合建议。缺失数据不推断为零；不自动改变项目。', {
      portfolio: {
        type: 'object'
      }
    }, ['portfolio'], async a => await Core.analyze(Core.validate(a.portfolio)));
  }
};
const __businessApply=module.exports.apply;module.exports.apply=function(ctx){require('./offline-adapter.cjs').register(ctx,"pp-leadership","ppl_license");return __businessApply(ctx);};
