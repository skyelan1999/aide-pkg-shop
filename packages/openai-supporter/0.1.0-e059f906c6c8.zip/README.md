# OpenAISupporter

Aide 的 OpenAI provider 支持插件，MIT 许可；不是 OpenAI 官方发布。它通过 Aide `providerSupport` protocol 1 声明 OpenAI 官方端点和一个带核验日期的 USD 价格快照。插件只提供静态数据，不注册 AI 工具，也不会读取或保存 API Key；端点匹配、请求和用量记录由 Aide 主程序处理。

当前版本只匹配 HTTPS `api.openai.com/v1`，并只按档案列出的精确模型 ID 计价。未知模型、代理地址和兼容服务继续使用 Aide 的手动费率。标准档位包括输入、输出和缓存命中输入价，单位为 USD/百万 tokens。Aide 会把 USD 与 CNY 分开显示，不做汇率换算。

此快照核验于 2026-10-30。OpenAI 价格可能变化，更新通过插件包交付，不在运行时抓取。GPT-5.6 Sol 页面注明的促销价至少有效至 2026-11-21；后续版本必须重新核验。输出为估算，不等同于 OpenAI 账单。

Aide 当前协议只描述标准档位，不描述 Batch、Fast/Ultrafast、缓存写入费、区域处理附加费、图像/音频/视频计费或其他按次收费工具；这些场景不应把本插件估算当成最终账单。缓存用量细节缺失时 Aide 按未命中输入估算并标记估算。

OpenAI API 没有可由普通模型 API Key 调用的 DeepSeek 风格余额端点。本插件不声明余额支持。组织 Usage/Costs API 是另一个需要组织管理员凭证的历史用量/费用接口，不是账户余额，当前不由本插件调用。不要把组织管理员密钥填入模型 API Key。

## 打包

```sh
python3 scripts/package.py
```

包使用显式文件白名单、固定 ZIP 时间戳和权限。市场发布时 Release ZIP 与市场 ZIP 使用同一文件和 SHA-256。
